% =========================================================================
% TFM: Analisis sobre la PLACA (tapa nueva)
% Amplitude versus distance + Amplitude spread by distance (boxplot) + Heatmap
% -------------------------------------------------------------------------
% Experimentos 5 a 13 (numeracion de la memoria). Solo hay que tocar el
% bloque 1 (elegir el preset).
%
% NOTA sobre unidades: voltaje_inyeccion esta en mV PICO A PICO, las mismas
% unidades que las amplitudes medidas (que tambien son pico a pico). 
% =========================================================================
clear; clc; close all;
addpath(fileparts(mfilename('fullpath')));   % para GeometriaTapaNueva.m

% =========================================================================
% 1. CONFIGURACION: elige un preset descomentandolo
% =========================================================================
ruta_base = 'C:\Users\julia\OneDrive\Escritorio\UPM\TFM\MATLAB';

% Cada preset define tambien voltaje_inyeccion, porque no todos los
% experimentos se hicieron con la misma tension.
%
% UNIDADES: voltaje_inyeccion va en mV PICO A PICO, igual que las amplitudes
% medidas. El generador se pone a 0,3 V de amplitud, que son 600 mVpp; por eso
% en casi todos los presets pone 600 y no 300. Los experimentos 12 y 13 se
% hicieron a 1 V y 1,2 V DE AMPLITUD, o sea 2000 y 2400 mVpp.

% --- (A) EXPERIMENTO 5: 1 electrodo de tension sobre la cuadricula interna (1 kHz con masa)
 % nombre_analisis      = 'Exp 5: single stimulating electrode, inner grid (1 kHz, grounded)';
 % carpetas             = {'EXPERIMENTO5\BM_06_verde', 'EXPERIMENTO5\BM_07_verde', 'EXPERIMENTO5\BM_08_verde'};
 % nombres_experimentos = {'Trial 1 (BM_06)', 'Trial 2 (BM_07)', 'Trial 3 (BM_08)'};
 % emisores             = 18;            % el mismo en las tres repeticiones
 % masa                 = [];
 % voltaje_inyeccion    = 600;
 % zona                 = 'cuadricula';   % solo pocillos 1-25
 % hacer_heatmap        = false;

% --- (B) EXPERIMENTO 6: 2 electrodos en fase (7 y 18)
% nombre_analisis      = 'Exp 6: two in-phase electrodes (7 and 18)';
% carpetas             = {'EXPERIMENTO6\bm_01', 'EXPERIMENTO6\bm_02', 'EXPERIMENTO6\bm_03'};
% nombres_experimentos = {'Trial 1', 'Trial 2', 'Trial 3'};
% emisores             = [7, 18];
% masa                 = 31;
% voltaje_inyeccion    = 600;
% zona                 = 'placa';         % los 37 pocillos
% hacer_heatmap        = true;

% --- (C) EXPERIMENTO 7: 1 electrodo de tension sobre la placa completa
% nombre_analisis      = 'Exp 7: one stimulating electrode (1 kHz)';
% carpetas             = {'EXPERIMENTO7\trial_1','EXPERIMENTO7\trial_2','EXPERIMENTO7\trial_3'};
% nombres_experimentos = {'Trial 1', 'Trial 2', 'Trial 3'};
% emisores             = 18;    masa = 31;    voltaje_inyeccion = 600;
% zona = 'placa';  hacer_heatmap = true;

% --- (D) EXPERIMENTO 8: 2 electrodos en fase (12 y 14). Linea base de los 9-13
% nombre_analisis      = 'Exp 8: two in-phase electrodes (12 and 14)';
% carpetas             = {'EXPERIMENTO8\trial_1','EXPERIMENTO8\trial_2','EXPERIMENTO8\trial_3'};
% nombres_experimentos = {'Trial 1', 'Trial 2', 'Trial 3'};
% emisores             = [12, 14];    masa = 31;    voltaje_inyeccion = 600;
% zona = 'placa';  hacer_heatmap = true;

% --- (E) EXPERIMENTO 9: 12/14 en fase 0 y 33/27 en fase PI
% nombre_analisis      = 'Exp 9: phase 0 at 12/14, phase PI at 33/27';
% carpetas             = {'EXPERIMENTO9\trial_1','EXPERIMENTO9\trial_2','EXPERIMENTO9\trial_3'};
% nombres_experimentos = {'Trial 1', 'Trial 2', 'Trial 3'};
% emisores             = [12, 14, 33, 27];    masa = 31;    voltaje_inyeccion = 600;
% zona = 'placa';  hacer_heatmap = true;

% --- (F) EXPERIMENTO 10 (colocacion ideal): 12/14 en fase 0 y 32/26 en fase PI
% nombre_analisis      = 'Exp 10: phase 0 at 12/14, phase PI at 32/26';
% carpetas             = {'EXPERIMENTO10\trial_1','EXPERIMENTO10\trial_2','EXPERIMENTO10\trial_3'};
% nombres_experimentos = {'Trial 1', 'Trial 2', 'Trial 3'};
% emisores             = [12, 14, 32, 26];    masa = 31;    voltaje_inyeccion = 600;
% zona = 'placa';  hacer_heatmap = true;

% --- (G) EXPERIMENTO 11: 12/14 en fase 0 y 3/23 en fase PI (se deforma)
% nombre_analisis      = 'Exp 11: phase 0 at 12/14, phase PI at 3/23';
% carpetas             = {'EXPERIMENTO11\trial_1','EXPERIMENTO11\trial_2','EXPERIMENTO11\trial_3'};
% nombres_experimentos = {'Trial 1', 'Trial 2', 'Trial 3'};
% emisores             = [12, 14, 3, 23];    masa = 31;    voltaje_inyeccion = 600;
% zona = 'placa';  hacer_heatmap = true;

% --- (H) EXPERIMENTO 12: misma colocacion que el 10 pero a 1 V
% nombre_analisis      = 'Exp 12: Exp 10 layout at 1 V';
% carpetas             = {'EXPERIMENTO12\trial_1','EXPERIMENTO12\trial_2','EXPERIMENTO12\trial_3'};
% nombres_experimentos = {'Trial 1', 'Trial 2', 'Trial 3'};
% emisores             = [12, 14, 32, 26];    masa = 31;    voltaje_inyeccion = 2000;   % 1 V de amplitud
% zona = 'placa';  hacer_heatmap = true;

% --- (I) EXPERIMENTO 13: misma colocacion que el 10 pero a 1,2 V
 nombre_analisis      = 'Exp 13: Exp 10 layout at 1.2 V';
 carpetas             = {'EXPERIMENTO13\trial_1','EXPERIMENTO13\trial_2','EXPERIMENTO13\trial_3'};
 nombres_experimentos = {'Trial 1', 'Trial 2', 'Trial 3'};
 emisores             = [12, 14, 32, 26];    masa = 31;    voltaje_inyeccion = 2400;   % 1,2 V de amplitud
 zona = 'placa';  hacer_heatmap = true;

colores_experimentos = {'#7f7f7f', '#2ca02c', '#98df8a'};

% -------------------------------------------------------------------------
% ESCALA DE COLOR DEL MAPA
% -------------------------------------------------------------------------
% [] = se ajusta al rango realmente medido, comun a los tres trials del
% experimento (asi son comparables entre si y se aprovecha todo el colormap).

%   [0 NaN]   -> todos los experimentos EMPIEZAN EN 0 y el maximo se ajusta.
%                Sin esto, en los Exp 12 y 13 (1 y 1,2 V) la primera marca de
%                la barra cae en 100-200 mV y en los de 0,6 V en 50, y parece
%                que las escalas arrancan en sitios distintos.
%   [0 300]   -> fija del todo (para comparar dos experimentos a la misma
%                tension con identica escala)
escala_colores_fija = [0 NaN];

% Alternativa para comparar experimentos a DISTINTA tension (Exp 10 frente a
% 12 y 13): pintar el mapa en % del maximo del trial. Todos los heatmaps van
% entonces de 0 a 100 % y se leen igual que las metricas de Analisis_Metricas.
% Con true se ignora escala_colores_fija.
mapa_en_porcentaje = false;

% -------------------------------------------------------------------------
% BOXPLOT DE DISPERSION POR DISTANCIA
% -------------------------------------------------------------------------
% La version antigua (boxchart con eje X numerico y una caja por trial) era
% ilegible: las cajas de 5.0 y 7.1 mm se montaban unas sobre otras y con
% tres trials salian 3x8 cajas estrechisimas. Esta version:
%   - eje X CATEGORICO (una posicion por distancia, equiespaciadas),
%   - UNA caja por distancia con los tres trials juntos (la dispersion que
%     interesa es la de pocillos a la misma distancia, no la de trials),
%   - encima, cada pocillo como un punto coloreado por trial, asi se ve
%     de donde sale la caja y si un trial se separa de los otros.
hacer_boxplot      = true;

nombre_cache = 'datos_Placa_v1.mat';

% =========================================================================
% 2. GEOMETRIA (unica y verificada)
% =========================================================================
[coord_X, coord_Y, geo] = GeometriaTapaNueva();
radio_placa_petri = geo.radio_placa_petri;

if strcmpi(zona, 'cuadricula')
    todos_los_pocillos = 1:25;
else
    todos_los_pocillos = 1:37;
end
puntos_posibles = setdiff(todos_los_pocillos, [emisores, masa]);

% Referencia de distancias: el emisor, o el centro geometrico si hay varios
X_ref = mean(coord_X(emisores));
Y_ref = mean(coord_Y(emisores));

if numel(emisores) == 1
    txt_eje_x = 'Absolute distance to the stimulating electrode (mm)';
else
    txt_eje_x = 'Distance to the emission centre (mm)';
end
txt_eje_y = 'Measured peak-to-peak amplitude (mV)';

datos_globales_amp  = [];
datos_globales_dist = [];
datos_globales_exp  = [];      % indice del trial de cada medida (para el boxplot)

fprintf('=== %s ===\n', nombre_analisis);
fprintf('Emisores: %s | Masa: %s | Referencia: (%.2f, %.2f) mm\n', ...
    mat2str(emisores), mat2str(masa), X_ref, Y_ref);
fprintf('Inyeccion: %d mV pico a pico\n\n', voltaje_inyeccion);

% =========================================================================
% 3. PASADA 1: LECTURA DE LOS .CSV (con cache)
% =========================================================================
datos = struct('nombre', {}, 'amp', {}, 'dist', {}, 'poc', {}, 'X', {}, 'Y', {});

for exp_idx = 1:length(carpetas)

    ruta_actual = fullfile(ruta_base, carpetas{exp_idx});
    nombre_exp  = nombres_experimentos{exp_idx};

    fprintf('Procesando: %s (%s)\n', nombre_exp, carpetas{exp_idx});
    if ~isfolder(ruta_actual)
        fprintf('  -> [AVISO] No existe la carpeta, se salta.\n'); continue;
    end

    archivo_cache = fullfile(ruta_actual, nombre_cache);

    if isfile(archivo_cache)
        fprintf('  -> Cargando desde cache...\n');
        load(archivo_cache, 'amplitudes_mV', 'distancias_radiales', ...
                            'pocillos_medidos', 'X_medidos', 'Y_medidos');
    else
        fprintf('  -> Leyendo .csv por primera vez (puede tardar)...\n');
        amplitudes_mV = []; distancias_radiales = [];
        pocillos_medidos = []; X_medidos = []; Y_medidos = [];

        for p = 1:length(puntos_posibles)
            id_pocillo = puntos_posibles(p);
            filepath = fullfile(ruta_actual, sprintf('%d.csv', id_pocillo));
            if ~isfile(filepath); continue; end

            X_act = coord_X(id_pocillo);
            Y_act = coord_Y(id_pocillo);
            dist_real = sqrt((X_act - X_ref)^2 + (Y_act - Y_ref)^2);

            val_mV = ExtraerPicoAPico(filepath);
            if isnan(val_mV); continue; end

            amplitudes_mV(end+1)       = val_mV;                %#ok<SAGROW>
            distancias_radiales(end+1) = round(dist_real, 1);   %#ok<SAGROW>
            pocillos_medidos(end+1)    = id_pocillo;            %#ok<SAGROW>
            X_medidos(end+1)           = X_act;                 %#ok<SAGROW>
            Y_medidos(end+1)           = Y_act;                 %#ok<SAGROW>
        end

        if ~isempty(amplitudes_mV)
            save(archivo_cache, 'amplitudes_mV', 'distancias_radiales', ...
                                'pocillos_medidos', 'X_medidos', 'Y_medidos');
            fprintf('  -> Cache guardada (%d pocillos).\n', numel(amplitudes_mV));
        end
    end

    if isempty(amplitudes_mV)
        fprintf('  -> [AVISO] Sin datos validos.\n'); continue;
    end

    datos(end+1) = struct('nombre', nombre_exp, 'amp', amplitudes_mV, ...
                          'dist', distancias_radiales, 'poc', pocillos_medidos, ...
                          'X', X_medidos, 'Y', Y_medidos);   %#ok<SAGROW>

    datos_globales_amp  = [datos_globales_amp,  amplitudes_mV];
    datos_globales_dist = [datos_globales_dist, distancias_radiales];
    datos_globales_exp  = [datos_globales_exp,  repmat(numel(datos), 1, numel(amplitudes_mV))];
end

if isempty(datos)
    error('No se ha podido leer ningun experimento. Revisa las rutas del bloque 1.');
end

% =========================================================================
% 4. ESCALA DE COLOR COMUN A TODOS LOS TRIALS DEL EXPERIMENTO
% =========================================================================
escala_auto = [min(datos_globales_amp), max(datos_globales_amp)];
if mapa_en_porcentaje
    escala_mapa = [0 100];
    txt_mapa    = 'Amplitude (% of the trial maximum)';
    fprintf('\nMapas en %% del maximo de cada trial: escala 0 a 100 %%\n\n');
else
    escala_mapa = escala_auto;
    if ~isempty(escala_colores_fija)
        fijo = ~isnan(escala_colores_fija);
        escala_mapa(fijo) = escala_colores_fija(fijo);
    end
    txt_mapa = 'Peak-to-peak amplitude (mV)';
    fprintf('\nEscala de color del mapa: %.0f a %.0f mV (%.0f%% a %.0f%% de la inyeccion; medido: %.0f a %.0f mV)\n\n', ...
        escala_mapa(1), escala_mapa(2), ...
        100*escala_mapa(1)/voltaje_inyeccion, 100*escala_mapa(2)/voltaje_inyeccion, ...
        escala_auto(1), escala_auto(2));
end

% =========================================================================
% 5. PASADA 2: GRAFICAS POR EXPERIMENTO
% =========================================================================
for exp_idx = 1:numel(datos)

    d = datos(exp_idx);
    nombre_exp   = d.nombre;
    color_actual = colores_experimentos{min(exp_idx, numel(colores_experimentos))};

    % --- A) DECAIMIENTO RADIAL --------------------------------------------
    dist_unicas   = unique(d.dist);
    ampl_medias   = zeros(1, numel(dist_unicas));
    etiq_pocillos = strings(1, numel(dist_unicas));
    for k = 1:numel(dist_unicas)
        sel = (d.dist == dist_unicas(k));
        ampl_medias(k)   = mean(d.amp(sel));
        etiq_pocillos(k) = strjoin(string(sort(d.poc(sel))), ',');
    end

    figure('Name', sprintf('Amplitude versus distance - %s', nombre_exp), ...
           'Position', [50 + exp_idx*25, 60 + exp_idx*25, 850, 520]);
    hold on; grid on;

    % Cada pocillo como punto hueco: con varios emisores, pocillos a la misma
    % distancia del centro pueden estar en direcciones opuestas y medir muy
    % distinto (Exp 10, 35 mm: de 17 a 87 mV). La media sola lo esconderia.
    scatter(d.dist, d.amp, 34, 'MarkerEdgeColor', color_actual, ...
            'MarkerEdgeAlpha', 0.55, 'LineWidth', 1, ...
            'DisplayName', 'Individual wells');
    plot(dist_unicas, ampl_medias, '-o', 'LineWidth', 2.5, 'MarkerSize', 8, ...
        'MarkerFaceColor', color_actual, 'Color', color_actual, ...
        'DisplayName', sprintf('%s (mean per distance)', nombre_exp));

    xticks(dist_unicas); xticklabels(string(dist_unicas)); xtickangle(45);
    % Eje Y comun a los tres trials (y desde 0), para que sean comparables
    ylim([0, 1.08 * max(datos_globales_amp)]);

    for k = 1:numel(dist_unicas)
        text(dist_unicas(k), ampl_medias(k), sprintf('  P%s', etiq_pocillos(k)), ...
             'FontSize', 8, 'Rotation', 60, 'Color', [0.35 0.35 0.35]);
    end

    xlabel(txt_eje_x, 'FontSize', 12, 'FontWeight', 'bold');
    ylabel(txt_eje_y, 'FontSize', 12, 'FontWeight', 'bold');
    title(sprintf('Amplitude versus distance: %s - %s', nombre_analisis, nombre_exp), 'FontSize', 13);
    lgd1 = legend('Location', 'northeast'); title(lgd1, 'Conditions');
    set(gca, 'FontSize', 11);

    if ~hacer_heatmap; continue; end

    % --- B) MAPA INTERPOLADO DEL POTENCIAL ---------------------------------
    % Solo con lo medido: sin emisores plantados ni valores en la pared. La
    % interpolacion (vecino natural) y la reflexion en la pared estan en
    % DibujarMapaPlaca.m.
    if mapa_en_porcentaje
        V_mapa = 100 * d.amp / max(d.amp);
    else
        V_mapa = d.amp;
    end
    figure('Name', sprintf('Peak-to-peak amplitude map - %s', nombre_exp), ...
           'Position', [100 + exp_idx*30, 100 + exp_idx*30, 700, 640]);
    DibujarMapaPlaca(d.X, d.Y, V_mapa, struct( ...
        'radio_placa', radio_placa_petri, ...
        'emisores_XY', [coord_X(emisores); coord_Y(emisores)], ...
        'masa_XY',     [coord_X(masa); coord_Y(masa)], ...
        'escala',      escala_mapa, ...
        'etiqueta',    txt_mapa, ...
        'titulo',      sprintf('Peak-to-peak amplitude: %s', nombre_exp)));
end

% =========================================================================
% 6. DISPERSION POR DISTANCIA: boxplot legible + resumen numerico
% =========================================================================
d_all = unique(datos_globales_dist);

% Etiqueta de cada distancia: los pocillos que hay a esa distancia (si son
% pocos) o cuantos son. Se calcula sobre puntos_posibles, no sobre lo medido,
% para que la etiqueta sea la misma aunque falte algun .csv.
dist_por_pocillo = round(hypot(coord_X(puntos_posibles) - X_ref, ...
                               coord_Y(puntos_posibles) - Y_ref), 1);
etiquetas_dist = strings(1, numel(d_all));
for k = 1:numel(d_all)
    pocillos_d = puntos_posibles(dist_por_pocillo == d_all(k));
    if numel(pocillos_d) <= 4
        etiquetas_dist(k) = sprintf('%.1f mm\\newlineP%s', d_all(k), strjoin(string(pocillos_d), ','));
    else
        etiquetas_dist(k) = sprintf('%.1f mm\\newline(%d wells)', d_all(k), numel(pocillos_d));
    end
end

if hacer_boxplot
    figure('Name', 'Amplitude spread by distance', 'Position', [420, 120, 1100, 600]);
    hold on; grid on;

    % Eje X por INDICE de distancia (1, 2, 3...), no por la distancia en mm:
    % asi las cajas quedan equiespaciadas y las de 5.0 y 7.1 mm no se solapan.
    % (Se usa indice numerico y no categorical para poder superponer el
    % scatter con desplazamiento: MATLAB no mezcla ejes categoricos y numericos.)
    [~, idx_dist] = ismember(datos_globales_dist, d_all);

    bx = boxchart(idx_dist, datos_globales_amp, ...
                  'BoxFaceColor', [0.55 0.55 0.55], 'BoxFaceAlpha', 0.25, ...
                  'BoxEdgeColor', [0.3 0.3 0.3], 'LineWidth', 1.2, ...
                  'MarkerStyle', 'none', ...            % los puntos se pintan aparte
                  'DisplayName', 'All trials (median, IQR, range)');

    % Un punto por pocillo y trial, con un pequeno desplazamiento horizontal
    % por trial para que no se tapen entre si.
    n_trials = numel(datos);
    desplaz  = linspace(-0.22, 0.22, n_trials);
    for t = 1:n_trials
        sel = (datos_globales_exp == t);
        col = colores_experimentos{min(t, numel(colores_experimentos))};
        scatter(idx_dist(sel) + desplaz(t), datos_globales_amp(sel), 30, ...
                'MarkerFaceColor', col, 'MarkerEdgeColor', 'k', ...
                'MarkerFaceAlpha', 0.85, 'LineWidth', 0.5, ...
                'DisplayName', datos(t).nombre);
    end

    xticks(1:numel(d_all)); xticklabels(cellstr(etiquetas_dist));
    xlim([0.4, numel(d_all) + 0.6]);
    xlabel([txt_eje_x ' / wells'], 'FontSize', 12, 'FontWeight', 'bold');
    ylabel(txt_eje_y, 'FontSize', 12, 'FontWeight', 'bold');
    title(sprintf('Amplitude spread by distance: %s', nombre_analisis), 'FontSize', 14);
    lgd2 = legend('Location', 'northeast'); title(lgd2, 'Conditions');
    set(gca, 'FontSize', 10, 'TickLabelInterpreter', 'tex');
end

fprintf('\n--- Resumen por distancia (todos los trials) ---\n');
for k = 1:numel(d_all)
    sel = (datos_globales_dist == d_all(k));
    fprintf('%6.1f mm : media %7.2f mV | sd %6.2f | min %6.1f | max %6.1f | n = %d\n', ...
        d_all(k), mean(datos_globales_amp(sel)), std(datos_globales_amp(sel)), ...
        min(datos_globales_amp(sel)), max(datos_globales_amp(sel)), sum(sel));
end
fprintf('-----------------------------------------------\n');

% =========================================================================
% FUNCIONES AUXILIARES
% =========================================================================
function val_mV = ExtraerPicoAPico(filepath)
% Peak-to-peak amplitude robusta: recorta los extremos del registro, suaviza y
% se queda con los percentiles 0.1 / 99.9 para no morder el ruido impulsivo.
    data = readmatrix(filepath);
    if size(data, 2) >= 2; v = data(:, 2); else; v = data(:, 1); end
    v = v(~isnan(v));
    if isempty(v); val_mV = NaN; return; end

    N = length(v);
    if N > 1000; v_limp = v(floor(N*0.1):floor(N*0.9)); else; v_limp = v; end

    v_suaves = smoothdata(v_limp, 'movmean', max(5, floor(N/1000)));
    val_mV = prctile(v_suaves, 99.9) - prctile(v_suaves, 0.1);
    if val_mV < 10; val_mV = val_mV * 1000; end   % V -> mV
end
