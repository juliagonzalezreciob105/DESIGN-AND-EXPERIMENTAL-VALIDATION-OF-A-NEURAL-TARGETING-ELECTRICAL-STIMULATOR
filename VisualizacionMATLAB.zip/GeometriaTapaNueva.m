function [coord_X, coord_Y, info] = GeometriaTapaNueva()
% =========================================================================
% TFM: Geometria OFICIAL de la tapa nueva (37 pocillos)
% -------------------------------------------------------------------------
% Uso:
%   [coord_X, coord_Y] = GeometriaTapaNueva();   -> solo devuelve coordenadas
%   GeometriaTapaNueva();                        -> ademas dibuja el mapa

% Comprobacion cruzada con los .csv (pocillos sin medir = electrodos).
% Numeracion de la memoria (carpetas EXPERIMENTOn):
%   Exp 5  (EXPERIMENTO5, BM_0x)  -> 18 (tension), sin masa, solo cuadricula
%   Exp 6  (EXPERIMENTO6, bm_0x)  -> 7, 18 (tension) + 31 (masa)
%   Exp 7  -> 18                  + 31
%   Exp 8  -> 12, 14              + 31
%   Exp 9  -> 12, 14 (fase 0) + 33, 27 (fase PI) + 31
%   Exp 10 -> 12, 14 (fase 0) + 32, 26 (fase PI) + 31
%   Exp 11 -> 12, 14 (fase 0) +  3, 23 (fase PI) + 31
%   Exp 12 y 13 -> igual que el 10 (a 1 V y 1,2 V)
% =========================================================================

% =========================================================================
% 1. CONSTANTES FISICAS DE LA TAPA
% =========================================================================
radio_placa_petri = 45;      % mm (placa Petri de 90 mm de diametro)
dist_agujeros     = 5;       % mm, paso de la cuadricula central 5x5
r_perif_interno   = 24.75;   % mm, anillo periferico interno (ejes)
r_perif_externo   = 35;      % mm, anillo periferico externo (ejes)

coord_X = zeros(1, 37);
coord_Y = zeros(1, 37);

% =========================================================================
% 2. CUADRICULA INTERNA (POCILLOS 1-25)
% -------------------------------------------------------------------------
% Numeracion por filas, de izquierda a derecha y de arriba a abajo:
%   1  2  3  4  5
%   6  7  8  9 10
%  11 12 13 14 15
%  16 17 18 19 20
%  21 22 23 24 25
% El pocillo 13 es el centro geometrico de la placa -> (0,0)
% =========================================================================
for i = 1:25
    coord_X(i) =  (i - (ceil(i/5) - 1)*5 - 3) * dist_agujeros;
    coord_Y(i) = -(ceil(i/5) - 3)             * dist_agujeros;
end

% =========================================================================
% 3. PERIFERIA (POCILLOS 26-37)
% -------------------------------------------------------------------------
% La numeracion arranca abajo (interno y luego externo) y va girando:
%   abajo -> diagonal inf-izq -> izquierda -> diagonal sup-izq ->
%   arriba -> diagonal sup-der -> derecha -> diagonal inf-der
% Las 4 diagonales estan a (+-24.75, +-24.75), es decir a r = 35 mm.
% =========================================================================
coord_X(26) =  0;                 coord_Y(26) = -r_perif_interno;  % abajo interno
coord_X(27) =  0;                 coord_Y(27) = -r_perif_externo;  % abajo externo
coord_X(28) = -r_perif_interno;   coord_Y(28) = -r_perif_interno;  % diagonal inf-izq
coord_X(29) = -r_perif_interno;   coord_Y(29) =  0;                % izquierda interno
coord_X(30) = -r_perif_externo;   coord_Y(30) =  0;                % izquierda externo
coord_X(31) = -r_perif_interno;   coord_Y(31) =  r_perif_interno;  % diagonal sup-izq (MASA habitual)
coord_X(32) =  0;                 coord_Y(32) =  r_perif_interno;  % arriba interno
coord_X(33) =  0;                 coord_Y(33) =  r_perif_externo;  % arriba externo
coord_X(34) =  r_perif_interno;   coord_Y(34) =  r_perif_interno;  % diagonal sup-der
coord_X(35) =  r_perif_interno;   coord_Y(35) =  0;                % derecha interno
coord_X(36) =  r_perif_externo;   coord_Y(36) =  0;                % derecha externo
coord_X(37) =  r_perif_interno;   coord_Y(37) = -r_perif_interno;  % diagonal inf-der

info = struct('radio_placa_petri', radio_placa_petri, ...
              'dist_agujeros',     dist_agujeros, ...
              'r_perif_interno',   r_perif_interno, ...
              'r_perif_externo',   r_perif_externo, ...
              'pocillos_cuadricula', 1:25, ...
              'pocillos_periferia',  26:37);

% =========================================================================
% 4. MAPA DE LA TAPA (solo si se llama sin recoger salidas)
% =========================================================================
if nargout > 0
    return;
end

figure('Name', 'New lid geometry (37 wells)', 'Position', [200, 100, 750, 730], 'Color', 'w');
hold on; axis equal; grid on;

% Contorno de la placa
rectangle('Position', [-radio_placa_petri, -radio_placa_petri, ...
                        radio_placa_petri*2, radio_placa_petri*2], ...
          'Curvature', [1, 1], 'LineWidth', 2.5, 'EdgeColor', 'k');

% Ejes de referencia
plot([-radio_placa_petri radio_placa_petri], [0 0], 'k:', 'Color', [0.7 0.7 0.7]);
plot([0 0], [-radio_placa_petri radio_placa_petri], 'k:', 'Color', [0.7 0.7 0.7]);

% Cuadricula central (verde) y periferia (gris)
plot(coord_X(1:25),  coord_Y(1:25),  'o', 'MarkerSize', 9, ...
     'MarkerFaceColor', '#2ca02c', 'MarkerEdgeColor', 'k');
plot(coord_X(26:37), coord_Y(26:37), 'o', 'MarkerSize', 11, ...
     'MarkerFaceColor', '#7f7f7f', 'MarkerEdgeColor', 'k');

% Etiqueta de cada pocillo
for i = 1:37
    text(coord_X(i), coord_Y(i) + 2.8, sprintf('%d', i), ...
         'HorizontalAlignment', 'center', 'FontSize', 10, ...
         'FontWeight', 'bold', 'Color', [0.75 0 0]);
end

xlim([-50 50]); ylim([-50 50]);
xlabel('X position (mm)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Y position (mm)', 'FontSize', 12, 'FontWeight', 'bold');
title('New lid: well numbering (13 = centre)', 'FontSize', 14);
legend('Inner grid, wells 1-25 (5 mm pitch)', 'Periphery, wells 26-37 (r = 24.75 / 35 mm)', ...
       'Location', 'southoutside', 'Orientation', 'horizontal');
set(gca, 'FontSize', 11);

% Tabla por consola
fprintf('\n--- Coordenadas tapa nueva (mm) ---\n');
for i = 1:37
    fprintf('Pocillo %2d: (%7.2f, %7.2f)   r = %6.2f\n', ...
        i, coord_X(i), coord_Y(i), hypot(coord_X(i), coord_Y(i)));
end
fprintf('-----------------------------------\n');

end
