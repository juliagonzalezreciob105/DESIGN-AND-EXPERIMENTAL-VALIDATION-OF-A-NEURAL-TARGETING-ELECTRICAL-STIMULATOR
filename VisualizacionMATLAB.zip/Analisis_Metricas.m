% =========================================================================
% TFM: METRICAS DE FOCALIZACION (coverage / spill) SOBRE LA PLACA
% -------------------------------------------------------------------------
% Va DESPUES de Analisis_Placa.m: alli se ve como es el campo (mapas y
% decaimiento); aqui se cuantifica si esta enfocado donde se queria.
% Aplica el apartado 2.7 de la memoria a los experimentos 9 a 13, que
% comparten la pareja 12/14 en fase 0 y cambian donde va la pareja en fase
% PI (y la tension en el 12 y el 13). Region objetivo: el pocillo 13.
%
% -------------------------------------------------------------------------
% 1) LA CLASIFICACION (Tabla 3 de la memoria)
% -------------------------------------------------------------------------
% Cada pocillo medido pertenece o no a la region objetivo, y esta o no
% activado (estimulado). Cuatro casillas:
%
%                          Activado          No activado
%   Pertenece al objetivo  TP                FN
%   No pertenece           FP (spill)        TN
%
%   Coverage = TP / (TP + FN)   fraccion del objetivo que se estimula
%   Spill    = FP / (FP + TN)   fraccion del resto de la placa que se estimula
%
% Las dos son tasas entre 0 y 1 (las dos normalizadas, a diferencia de [22]),
% se dan POR SEPARADO y no se combinan en una sola cifra de merito.
%
% -------------------------------------------------------------------------
% 2) LAS DOS ADAPTACIONES
% -------------------------------------------------------------------------
% (a) Se mide potencial, no activacion -> "activado" se define con un UMBRAL
%     sobre la amplitud, y las metricas se dan siempre junto al umbral.
%     El umbral es RELATIVO: umbral_fijo x maximo del trial. Permite comparar
%     experimentos a 0,6 / 1 / 1,2 V y no presupone ningun valor absoluto de
%     activacion, que en PBS no se conoce. (Un umbral absoluto en mV solo
%     tendria sentido entre experimentos a la misma tension.)
% (b) Se mide en una rejilla -> las metricas se cuentan sobre POCILLOS, y su
%     resolucion la fija el paso de 5 mm. Se dice en todas las figuras.
%
% -------------------------------------------------------------------------
% 3) LA REGION OBJETIVO
% -------------------------------------------------------------------------
%   Solo el pocillo 13 (una celda de 5 x 5 mm, del orden del LGN y el limite
%   de resolucion de la rejilla). Entonces TP + FN = 1 y coverage solo vale
%   1 o 0: "esta el 13 activado?". La metrica que discrimina es el spill.
%
% -------------------------------------------------------------------------
% 4) DOS UMBRALES PORQUE SON DOS PREGUNTAS
% -------------------------------------------------------------------------
% UMBRAL 100 %: "SE ENFOCA EN EL OBJETIVO?"
%   Al 100 % solo esta activado el pocillo mas fuerte del trial. Coverage es
%   1 si ese pocillo cae dentro del objetivo y 0 si no. Es un si/no sin nada
%   arbitrario: decide el veredicto FOCUSED / NOT focused.
% UMBRAL FIJO (70 %): "COMO DE ANCHO ES EL FOCO?"
%   Estan activados el maximo y los que se le acercan. Spill = fraccion de
%   la placa casi tan fuerte como el maximo. Aqui si se elige un numero, pero
%   el orden de los experimentos no depende de el: para cualquier umbral
%   entre 50 y 90 % el spill ordena {Exp 12, 13} < {Exp 9, 10} < Exp 11
%   (comprobado; dentro de cada llave son casi iguales).
% -------------------------------------------------------------------------
% 5) LO QUE SALE
% -------------------------------------------------------------------------
%   Fig. "Targeting summary per exp."  un panel por experimento y una barra
%                                      por trial: color = FOCUSED / NOT focused
%                                      (y donde cae el maximo), altura = spill
%                                      al umbral fijo. Resume los mapas.
%   Fig. "Focus verdict per trial"     una figura por experimento, con sus 3
%                                      trials (activado o no) y el veredicto
%   Metricas_resultados.xlsx           hojas Per trial, Summary (la tabla
%                                      completa; no se dibuja como figura)
%
% Todo el texto de las figuras esta en ingles.
% =========================================================================
clear; clc; close all;
addpath(fileparts(mfilename('fullpath')));   % GeometriaTapaNueva, DibujarMapaPlaca

% =========================================================================
% 1. CONFIGURACION
% =========================================================================
ruta_base = 'C:\Users\julia\OneDrive\Escritorio\UPM\TFM\MATLAB';

% Experimentos a comparar. Todos con la pareja 12/14 en fase 0; cambia donde
% esta la pareja en fase PI y la tension. Descomenta el Exp 8 si quieres la
% linea base sin pareja PI.
exps = struct('nombre', {}, 'carpeta', {}, 'emisores', {}, 'masa', {}, 'voltaje', {});
% exps(end+1) = struct('nombre', 'Exp 8: 12/14 only (baseline)', 'carpeta', 'EXPERIMENTO8',  'emisores', [12 14],       'masa', 31, 'voltaje', 600);
exps(end+1) = struct('nombre', 'Exp 9: PI at 33/27',            'carpeta', 'EXPERIMENTO9',  'emisores', [12 14 33 27], 'masa', 31, 'voltaje', 600);
exps(end+1) = struct('nombre', 'Exp 10: PI at 32/26',           'carpeta', 'EXPERIMENTO10', 'emisores', [12 14 32 26], 'masa', 31, 'voltaje', 600);
exps(end+1) = struct('nombre', 'Exp 11: PI at 3/23',            'carpeta', 'EXPERIMENTO11', 'emisores', [12 14 3 23],  'masa', 31, 'voltaje', 600);
exps(end+1) = struct('nombre', 'Exp 12: PI at 32/26, 1 V',      'carpeta', 'EXPERIMENTO12', 'emisores', [12 14 32 26], 'masa', 31, 'voltaje', 2000);
exps(end+1) = struct('nombre', 'Exp 13: PI at 32/26, 1.2 V',    'carpeta', 'EXPERIMENTO13', 'emisores', [12 14 32 26], 'masa', 31, 'voltaje', 2400);

trials       = 1:3;
nombre_cache = 'datos_Placa_v1.mat';        % la misma cache que Analisis_Placa

pocillo_objetivo = 13;       % region objetivo: solo este pocillo
umbral_fijo      = 0.70;     % "activado" = amplitud >= umbral_fijo x maximo del trial

% =========================================================================
% 2. GEOMETRIA Y LECTURA
% =========================================================================
[coord_X, coord_Y, geo] = GeometriaTapaNueva();
R = geo.radio_placa_petri;

n_exp = numel(exps);
n_tr  = numel(trials);
datos = cell(n_exp, n_tr);   % cada celda: struct con amp, poc, X, Y

for e = 1:n_exp
    puntos_posibles = setdiff(1:37, [exps(e).emisores, exps(e).masa]);
    for t = 1:n_tr
        ruta = fullfile(ruta_base, exps(e).carpeta, sprintf('trial_%d', trials(t)));
        if ~isfolder(ruta)
            fprintf('[AVISO] No existe %s\n', ruta); continue;
        end
        archivo_cache = fullfile(ruta, nombre_cache);
        if isfile(archivo_cache)
            S = load(archivo_cache, 'amplitudes_mV', 'pocillos_medidos', 'X_medidos', 'Y_medidos');
        else
            fprintf('Leyendo .csv de %s (primera vez)...\n', ruta);
            S = LeerTrial(ruta, puntos_posibles, coord_X, coord_Y, exps(e).emisores, archivo_cache);
        end
        if isempty(S.amplitudes_mV); continue; end
        datos{e, t} = struct('amp', S.amplitudes_mV(:)', 'poc', S.pocillos_medidos(:)', ...
                             'X', S.X_medidos(:)', 'Y', S.Y_medidos(:)');
    end
end

% --- Textos que describen objetivo y umbral (para figuras y tablas) -------
txt_obj       = sprintf('well %d', pocillo_objetivo);
txt_umb       = sprintf('%.0f %% of the trial maximum', 100*umbral_fijo);
txt_umb_corto = sprintf('%.0f %%', 100*umbral_fijo);

% =========================================================================
% 3. METRICAS SOBRE LA REJILLA (pocillos)
% =========================================================================
cov_fijo   = nan(n_exp, n_tr);        % al umbral fijo (relativo o absoluto)
spill_fijo = nan(n_exp, n_tr);
umbral_mV  = nan(n_exp, n_tr);        % el umbral fijo en mV, trial a trial
amp_rel_13 = nan(n_exp, n_tr);        % amplitud del 13 / maximo del trial
rango_13   = nan(n_exp, n_tr);        % posicion del 13 en el ranking (1 = el mas fuerte)
poc_max    = nan(n_exp, n_tr);        % pocillo mas fuerte del trial
enfocado   = false(n_exp, n_tr);      % veredicto al 100 %: el maximo cae en el objetivo
n_obj      = nan(n_exp, n_tr);        % pocillos del objetivo medidos
n_otros    = nan(n_exp, n_tr);        % pocillos fuera del objetivo medidos
clases     = cell(n_exp, n_tr);       % clase de cada pocillo al umbral fijo

for e = 1:n_exp
    for t = 1:n_tr
        d = datos{e, t};
        if isempty(d); continue; end
        i13    = (d.poc == pocillo_objetivo);
        es_obj = i13;
        if ~any(i13)
            fprintf('[AVISO] %s trial %d: el pocillo %d no esta medido.\n', exps(e).nombre, t, pocillo_objetivo);
            continue;
        end
        n_obj(e, t)   = sum(es_obj);
        n_otros(e, t) = sum(~es_obj);
        amp_max = max(d.amp);
        [~, i_max] = max(d.amp);

        amp_rel_13(e, t) = d.amp(i13) / amp_max;
        rango_13(e, t)   = sum(d.amp >= d.amp(i13));   % 1 = el 13 es el maximo
        poc_max(e, t)    = d.poc(i_max);
        enfocado(e, t)   = es_obj(i_max);              % = coverage al 100 %

        umbral_mV(e, t) = umbral_fijo * amp_max;
        act_fijo = d.amp >= umbral_mV(e, t);
        [cov_fijo(e, t), spill_fijo(e, t)] = CoverageSpill(act_fijo, es_obj);
        clases{e, t} = ClasificarPocillos(act_fijo, es_obj);   % 1 TP, 2 FP, 3 FN, 4 TN
    end
end

n_otros_tip = mode(n_otros(isfinite(n_otros)));   % normalmente 31

% =========================================================================
% 5. TABLA POR CONSOLA
% =========================================================================
fprintf('\n=== Targeting metrics. Target: %s. Threshold: %s ===\n', txt_obj, txt_umb);
fprintf('%-32s | %-18s | %-16s | %-16s | %-12s | %s\n', 'Experiment', 'Focused (100 %)', ...
        'Coverage', 'Spill', 'A13 / Amax', 'Rank of 13');
for e = 1:n_exp
    fprintf('%-32s | %d of %d trials      | %4.2f (%s) | %4.2f (%s) | %4.2f (%s) | %s\n', exps(e).nombre, ...
        sum(enfocado(e, :)), n_tr, ...
        mean(cov_fijo(e, :), 'omitnan'),   strjoin(compose('%.2f', cov_fijo(e, :)), ','), ...
        mean(spill_fijo(e, :), 'omitnan'), strjoin(compose('%.2f', spill_fijo(e, :)), ','), ...
        mean(amp_rel_13(e, :), 'omitnan'), strjoin(compose('%.2f', amp_rel_13(e, :)), ','), ...
        strjoin(compose('%d', rango_13(e, :)), ','));
end
fprintf('(entre parentesis, los tres trials)\n');

% =========================================================================
% 6. FIGURA B: RESUMEN DE LOS MAPAS, UN PANEL POR EXPERIMENTO
% -------------------------------------------------------------------------
% Condensa lo que dice cada mapa de la Fig. C en una barra por trial:
%   color de la barra -> veredicto (verde FOCUSED, rojo NOT focused; si es
%                        rojo, encima se dice en que pocillo cae el maximo)
%   altura de la barra -> pocillos fuera del objetivo activados al umbral
%                        fijo (anchura del foco); encima, el spill en %
% Asi las dos preguntas (se enfoca? como de ancho?) se leen de un vistazo y
% por experimento, sin repetir la tabla (que ya va al Excel).
% =========================================================================
etiq_exp = arrayfun(@(s) extractBefore([s.nombre ':'], ':'), exps, 'UniformOutput', false);
verde   = [0.10 0.55 0.10];
rojo    = [0.80 0.10 0.10];

figure('Name', 'Targeting summary per experiment', 'Position', [100 120 1150 520], 'Color', 'w');
tl = tiledlayout(1, n_exp, 'TileSpacing', 'compact', 'Padding', 'compact');
title(tl, sprintf('Spill per trial (target: %s; "on" = amplitude at or above %s)', txt_obj, txt_umb), ...
      'FontSize', 13, 'FontWeight', 'bold');

for e = 1:n_exp
    ax = nexttile(tl); hold(ax, 'on'); grid(ax, 'on');
    for t = 1:n_tr
        if ~isfinite(spill_fijo(e, t)); continue; end
        if enfocado(e, t); col = verde; else; col = rojo; end
        n_fp = sum(clases{e, t} == 2);            % pocillos fuera del objetivo activados
        bar(ax, t, n_fp, 0.65, 'FaceColor', col, 'FaceAlpha', 0.75, 'EdgeColor', col);
        text(ax, t, n_fp + 0.5, sprintf('%.0f %%', 100*spill_fijo(e, t)), ...
             'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', 'FontSize', 9);
        if ~enfocado(e, t)
            text(ax, t, n_fp + 3.5, sprintf('max at\nwell %d', poc_max(e, t)), ...
                 'HorizontalAlignment', 'center', 'VerticalAlignment', 'bottom', ...
                 'FontSize', 8, 'Color', rojo, 'FontWeight', 'bold');
        end
    end
    xticks(ax, 1:n_tr); xticklabels(ax, compose('Trial %d', trials));
    xlim(ax, [0.4 n_tr + 0.6]); ylim(ax, [0 n_otros_tip + 3]); yticks(ax, 0:5:n_otros_tip);
    title(ax, {exps(e).nombre, sprintf('Focused: %d of %d', sum(enfocado(e, :)), n_tr)}, 'FontSize', 10);
    if e == 1
        ylabel(ax, sprintf('Non-target wells "on" (of %d)', n_otros_tip));
    else
        yticklabels(ax, []);
    end
    set(ax, 'FontSize', 9, 'Box', 'off', 'TickDir', 'out');
end
h_f  = fill(ax, nan, nan, verde, 'FaceAlpha', 0.75, 'EdgeColor', verde);
h_nf = fill(ax, nan, nan, rojo,  'FaceAlpha', 0.75, 'EdgeColor', rojo);
lg = legend(ax, [h_f h_nf], ...
    {sprintf('FOCUSED (maximum in well %d)', pocillo_objetivo), 'NOT focused (maximum elsewhere)'}, ...
    'NumColumns', 2, 'FontSize', 10, 'Box', 'off', 'AutoUpdate', 'off');
lg.Layout.Tile = 'south';
% Nota al pie: que es el numero que hay encima de cada barra.
xlabel(tl, sprintf(['Bar height = non-target wells "on" in that trial. Number above the bar = spill = ' ...
    'that count divided by the %d non-target wells, in %%. Bar colour = whether the strongest well of the trial is the target.'], n_otros_tip), ...
    'FontSize', 9.5, 'Color', [0.3 0.3 0.3]);

% =========================================================================
% 7. FIGURA C: VEREDICTO. Se enfoca en el objetivo o no, trial a trial
% -------------------------------------------------------------------------
% Dos colores: pocillo activado (amplitud >= umbral fijo) o no. Veredicto:
%   FOCUSED     -> el pocillo mas fuerte del trial cae en el objetivo
%                  (coverage al 100 % = 1). Si/no, no depende del umbral.
%   NOT focused -> el maximo esta fuera del objetivo (se dice donde).
% El numero de pocillos activados fuera del objetivo dice como de ancho es
% el foco; ese si depende del umbral.
% =========================================================================
col_on  = [0.12 0.47 0.71];   % activado
col_off = [0.92 0.92 0.92];   % no activado

% Una figura por experimento, con los trials en una fila y leyenda comun.
for e = 1:n_exp
        fig = figure('Name', sprintf('Focus verdict per trial - %s', ...
            etiq_exp{e}), 'NumberTitle', 'off', ...
            'Position', [40 100 1500 650], 'Color', 'w', 'Tag', 'FocusVerdictExperiment');
        tl = tiledlayout(fig, 1, n_tr, 'TileSpacing', 'compact', 'Padding', 'compact');
        title(tl, exps(e).nombre, 'FontSize', 13, 'FontWeight', 'bold');
    for t = 1:n_tr
        ax = nexttile(tl); hold(ax, 'on'); axis(ax, 'equal');
        title(ax, sprintf('Trial %d', trials(t)), 'FontSize', 12);
        rectangle(ax, 'Position', [-R -R 2*R 2*R], 'Curvature', [1 1], ...
            'LineWidth', 1.2, 'EdgeColor', [0.4 0.4 0.4]);
        d = datos{e, t}; cl = clases{e, t};
        if ~isempty(d) && ~isempty(cl)
            act = (cl == 1) | (cl == 2);
            scatter(ax, d.X(~act), d.Y(~act), 95, col_off, 'filled', 'MarkerEdgeColor', [0.6 0.6 0.6]);
            scatter(ax, d.X(act), d.Y(act), 95, col_on, 'filled', 'MarkerEdgeColor', 'k');
            plot(ax, coord_X(poc_max(e,t)), coord_Y(poc_max(e,t)), 'd', ...
                'MarkerSize', 15, 'LineWidth', 1.7, 'Color', [0.85 0.4 0]);
            if enfocado(e, t)
                txt = 'FOCUSED'; col_v = verde;
            else
                txt = sprintf('NOT focused (maximum at well %d)', poc_max(e, t)); col_v = rojo;
            end
            text(ax, 0, -48, txt, 'HorizontalAlignment', 'center', ...
                'FontSize', 10, 'FontWeight', 'bold', 'Color', col_v);
            text(ax, 0, 48, sprintf('Spill: %d of %d wells (%.0f %%)', ...
                sum(cl == 2), n_otros(e,t), 100*spill_fijo(e,t)), ...
                'HorizontalAlignment', 'center', 'FontSize', 11);
        else
            text(ax, 0, -48, 'No valid target data - verdict unavailable', ...
                'HorizontalAlignment', 'center', 'FontSize', 11);
        end
        plot(ax, coord_X(pocillo_objetivo), coord_Y(pocillo_objetivo), 'o', ...
            'MarkerSize', 21, 'LineWidth', 1.8, 'Color', [0.5 0.15 0.7]);
        plot(ax, coord_X(exps(e).emisores), coord_Y(exps(e).emisores), 'r+', 'MarkerSize', 10, 'LineWidth', 1.8);
        plot(ax, coord_X(exps(e).masa), coord_Y(exps(e).masa), 'ks', 'MarkerSize', 8, 'MarkerFaceColor', 'k');
        for p = 1:numel(coord_X)
            text(ax, coord_X(p)+1.5, coord_Y(p)+1.5, sprintf('%d', p), ...
                'FontSize', 8, 'Color', [0.2 0.2 0.2]);
        end
        xlim(ax, [-52 52]); ylim(ax, [-52 52]);
        xlabel(ax, 'x (mm)'); ylabel(ax, 'y (mm)');
        set(ax, 'FontSize', 10, 'Box', 'off', 'TickDir', 'out');
    end
        % Handles explicitos del mismo eje: leyenda estable incluso sin datos.
        h_on = scatter(ax, nan, nan, 95, col_on, 'filled', 'MarkerEdgeColor', 'k');
        h_off = scatter(ax, nan, nan, 95, col_off, 'filled', 'MarkerEdgeColor', [0.6 0.6 0.6]);
        h_target = plot(ax, nan, nan, 'o', 'MarkerSize', 12, 'LineWidth', 1.8, 'Color', [0.5 0.15 0.7]);
        h_max = plot(ax, nan, nan, 'd', 'MarkerSize', 10, 'LineWidth', 1.7, 'Color', [0.85 0.4 0]);
        h_em = plot(ax, nan, nan, 'r+', 'MarkerSize', 10, 'LineWidth', 1.8);
        h_gnd = plot(ax, nan, nan, 'ks', 'MarkerSize', 8, 'MarkerFaceColor', 'k');
        lg = legend(ax, [h_on h_off h_target h_max h_em h_gnd], ...
            {sprintf('At or above %s of the trial maximum', txt_umb_corto), 'Below', ...
             sprintf('Target (well %d)', pocillo_objetivo), 'Maximum amplitude', 'Stimulating electrodes', 'Ground'}, ...
            'NumColumns', 6, 'FontSize', 10, 'Box', 'off', 'AutoUpdate', 'off');
        lg.Layout.Tile = 'south';
% Nota al pie: que es el numero que hay encima de cada barra.
xlabel(tl, sprintf(['Bar height = non-target wells "on" in that trial. Number above the bar = spill = ' ...
    'that count divided by the %d non-target wells, in %%. Bar colour = whether the strongest well of the trial is the target.'], n_otros_tip), ...
    'FontSize', 9.5, 'Color', [0.3 0.3 0.3]);
    end
% =========================================================================
% 8. TABLAS: por trial y resumen por experimento
% -------------------------------------------------------------------------
% Se imprimen por consola y se guardan en Excel (dos hojas). La figura que
% las resume es la B (seccion 6). En Summary solo van medias: con 3 trials
% la SD no aporta nada y los valores trial a trial ya estan en Per trial.
% =========================================================================
filas = {};
for e = 1:n_exp
    for t = 1:n_tr
        d = datos{e, t}; cl = clases{e, t};
        if isempty(d) || isempty(cl); continue; end
        i13  = (d.poc == pocillo_objetivo);
        amax = max(d.amp);
        fp_wells = sort(d.poc(cl == 2));
        if isempty(fp_wells); txt_fp = '-'; else; txt_fp = strjoin(compose('%d', fp_wells), ' '); end
        filas(end+1, :) = {exps(e).nombre, trials(t), amax, poc_max(e, t), d.amp(i13), 100*d.amp(i13)/amax, ...
                           umbral_mV(e, t), n_obj(e, t), sum(cl == 1), n_otros(e, t), sum(cl == 2), ...
                           cov_fijo(e, t), spill_fijo(e, t), enfocado(e, t), rango_13(e, t), txt_fp}; %#ok<SAGROW>
    end
end
T_trials = cell2table(filas, 'VariableNames', {'Experiment', 'Trial', 'Max_amplitude_mV', 'Max_well', ...
    'Well13_amplitude_mV', 'Well13_pct_of_max', 'Threshold_mV', 'Target_wells', 'Target_wells_stimulated', ...
    'Other_wells', 'Other_wells_stimulated', 'Coverage', 'Spill', 'Focused_100pct', 'Rank_of_well13', ...
    'Other_wells_stimulated_list'});

filas = {};
for e = 1:n_exp
    filas(end+1, :) = {exps(e).nombre, sum(enfocado(e, :)), sum(isfinite(rango_13(e, :))), ...
        mean(cov_fijo(e, :), 'omitnan'), mean(spill_fijo(e, :), 'omitnan'), ...
        mean(T_trials.Other_wells_stimulated(strcmp(T_trials.Experiment, exps(e).nombre))), ...
        mean(amp_rel_13(e, :), 'omitnan') * 100}; %#ok<SAGROW>
end
T_resumen = cell2table(filas, 'VariableNames', {'Experiment', 'Focused_trials', 'Trials', ...
    'Coverage_mean', 'Spill_mean', 'Other_wells_stimulated_mean', ...
    'Well13_pct_of_max_mean'});

fprintf('\n--- Per trial (target: %s; threshold: %s) ---\n', txt_obj, txt_umb);
disp(T_trials);
fprintf('--- Summary per experiment ---\n');
disp(T_resumen);

archivo_xlsx = fullfile(fileparts(mfilename('fullpath')), 'Metricas_resultados.xlsx');
try
    if isfile(archivo_xlsx); delete(archivo_xlsx); end
    writetable(T_trials,  archivo_xlsx, 'Sheet', 'Per trial');
    writetable(T_resumen, archivo_xlsx, 'Sheet', 'Summary');
    fprintf('Tablas guardadas en %s\n', archivo_xlsx);
catch ME
    warning('No se ha podido escribir %s (esta abierto en Excel?): %s', archivo_xlsx, ME.message);
end

% =========================================================================
% FUNCIONES AUXILIARES
% =========================================================================
function [cov, spill] = CoverageSpill(act, es_obj)
% act y es_obj: logicos del mismo tamano (pocillos o pixeles).
    TP = sum(act & es_obj);   FN = sum(~act & es_obj);
    FP = sum(act & ~es_obj);  TN = sum(~act & ~es_obj);
    cov   = TP / max(TP + FN, 1);
    spill = FP / max(FP + TN, 1);
end

function cl = ClasificarPocillos(act, es_obj)
% 1 = TP, 2 = FP, 3 = FN, 4 = TN
    cl = zeros(size(act));
    cl(act & es_obj)   = 1;
    cl(act & ~es_obj)  = 2;
    cl(~act & es_obj)  = 3;
    cl(~act & ~es_obj) = 4;
end

function S = LeerTrial(ruta, puntos_posibles, coord_X, coord_Y, emisores, archivo_cache)
    X_ref = mean(coord_X(emisores)); Y_ref = mean(coord_Y(emisores));
    amplitudes_mV = []; distancias_radiales = []; pocillos_medidos = []; X_medidos = []; Y_medidos = [];
    for p = puntos_posibles
        f = fullfile(ruta, sprintf('%d.csv', p));
        if ~isfile(f); continue; end
        val = ExtraerPicoAPico(f);
        if isnan(val); continue; end
        amplitudes_mV(end+1)       = val;                                              %#ok<AGROW>
        distancias_radiales(end+1) = round(hypot(coord_X(p) - X_ref, coord_Y(p) - Y_ref), 1); %#ok<AGROW>
        pocillos_medidos(end+1)    = p;                                                %#ok<AGROW>
        X_medidos(end+1)           = coord_X(p);                                       %#ok<AGROW>
        Y_medidos(end+1)           = coord_Y(p);                                       %#ok<AGROW>
    end
    if ~isempty(amplitudes_mV)
        save(archivo_cache, 'amplitudes_mV', 'distancias_radiales', 'pocillos_medidos', 'X_medidos', 'Y_medidos');
    end
    S = struct('amplitudes_mV', amplitudes_mV, 'pocillos_medidos', pocillos_medidos, ...
               'X_medidos', X_medidos, 'Y_medidos', Y_medidos);
end

function val_mV = ExtraerPicoAPico(filepath)
    data = readmatrix(filepath);
    if size(data, 2) >= 2; v = data(:, 2); else; v = data(:, 1); end
    v = v(~isnan(v));
    if isempty(v); val_mV = NaN; return; end
    N = length(v);
    if N > 1000; v_limp = v(floor(N*0.1):floor(N*0.9)); else; v_limp = v; end
    v_suaves = smoothdata(v_limp, 'movmean', max(5, floor(N/1000)));
    val_mV = prctile(v_suaves, 99.9) - prctile(v_suaves, 0.1);
    if val_mV < 10; val_mV = val_mV * 1000; end
end

