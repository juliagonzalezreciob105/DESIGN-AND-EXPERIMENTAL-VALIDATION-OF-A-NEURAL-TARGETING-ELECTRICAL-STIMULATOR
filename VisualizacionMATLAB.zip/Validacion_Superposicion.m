% =========================================================================
% TFM: EXPERIMENTO 3. Comparativa de Superposición (Suma vs Real)
% No tiene carpeta propia: usa dos trials del Exp 5 (un electrodo solo,
% BM_07_verde y BM_09_azul) y uno del Exp 6 (los dos electrodos, bm_02).
% =========================================================================
clear; clc; close all;

% =========================================================================
% 1. RUTAS A LOS EXPERIMENTOS Y ETIQUETAS
% =========================================================================
rutas_experimentos = {
    'C:\Users\julia\OneDrive\Escritorio\UPM\TFM\MATLAB\EXPERIMENTO5\BM_07_verde', ... % Solo electrodo 1 (Exp 5)
    'C:\Users\julia\OneDrive\Escritorio\UPM\TFM\MATLAB\EXPERIMENTO5\BM_09_azul',  ... % Solo electrodo 2 (Exp 5)
    'C:\Users\julia\OneDrive\Escritorio\UPM\TFM\MATLAB\EXPERIMENTO6\bm_02'        % Ambos electrodos (Exp 6)
};

% Posiciones de la linea que existen en los TRES experimentos (columna central de la cuadricula)
archivos = {'3.csv', '8.csv', '13.csv', '23.csv'};

% =========================================================================
% 2. VARIABLES PARA GUARDAR LOS RESULTADOS
% =========================================================================
nombres_validos = {};
vpp1_array = [];
vpp2_array = [];
vpp_teorico_array = [];
vpp_real_array = [];
error_array = [];
ondas = struct('nombre', {}, 't', {}, 'v1', {}, 'v2', {}, 'suma', {}, 'real', {}, 'vpp_suma', {}, 'vpp_real', {});

disp('--- Análisis de Amplitudes Peak-to-Peak (Vpp) ---');

% =========================================================================
% 3. CÁLCULO DE Vpp POR POSICIÓN
% =========================================================================
for i = 1:length(archivos)
    nombre_archivo = archivos{i};
    
    ruta1 = fullfile(rutas_experimentos{1}, nombre_archivo);
    ruta2 = fullfile(rutas_experimentos{2}, nombre_archivo);
    ruta3 = fullfile(rutas_experimentos{3}, nombre_archivo);
    
    % Comprobar existencia
    if ~isfile(ruta1) || ~isfile(ruta2) || ~isfile(ruta3)
        fprintf('⚠️ Posición %s omitida: Faltan datos.\n', nombre_archivo);
        continue; 
    end
    
    % Cargar datos y limpiar NaNs (solo nos interesa la tensión, columna 2)
    data1 = rmmissing(readmatrix(ruta1)); v1 = data1(:, 2);
    data2 = rmmissing(readmatrix(ruta2)); v2 = data2(:, 2);
    data3 = rmmissing(readmatrix(ruta3)); v3 = data3(:, 2);
    
    % Asegurar que solo usamos valores finitos
    v1 = v1(isfinite(v1));
    v2 = v2(isfinite(v2));
    v3 = v3(isfinite(v3));
    
    % --- CÁLCULO DEL Vpp ---
    % Mismo metodo que el resto de scripts (percentiles 0.1 / 99.9 sobre la
    % señal suavizada, recortando el 10 % de cada extremo). Antes era
    % max - min crudo, que con ruido impulsivo inflaba las barras.
    onda = PrepararOndas(data1, data2, data3, nombre_archivo);
    if ~isempty(onda), ondas(end+1) = onda; end %#ok<SAGROW>
    vpp1 = 1000 * VppRobusto(v1);      % mV, como el resto de scripts
    vpp2 = 1000 * VppRobusto(v2);
    vpp3 = 1000 * VppRobusto(v3);
    
    % Superposición teórica de amplitudes
    vpp_suma_teorica = vpp1 + vpp2;
    
    % Error absoluto (Caída de tensión)
    error_vpp = abs(vpp_suma_teorica - vpp3);
    
    % Guardar datos para la gráfica
    nombres_validos{end+1} = nombre_archivo; %#ok<SAGROW>
    vpp1_array(end+1) = vpp1; %#ok<SAGROW>
    vpp2_array(end+1) = vpp2; %#ok<SAGROW>
    vpp_teorico_array(end+1) = vpp_suma_teorica; %#ok<SAGROW>
    vpp_real_array(end+1) = vpp3; %#ok<SAGROW>
    error_array(end+1) = error_vpp; %#ok<SAGROW>
    
    % Imprimir en consola para revisión rápida
    fprintf('Posición %s: Vpp1=%.0f | Vpp2=%.0f | Suma=%.0f | Real=%.0f | Diff=%.0f mV\n', ...
        nombre_archivo, vpp1, vpp2, vpp_suma_teorica, vpp3, error_vpp);
end

% =========================================================================
% 4. REPRESENTACIÓN GRÁFICA: 4 Barras por Posición
% =========================================================================
if ~isempty(nombres_validos)
    figure('Name', 'Peak-to-peak amplitude comparison (Vpp)', 'Position', [100, 100, 900, 600], 'Color', 'w');
    
    % Agrupar datos: [Electrodo1, Electrodo2, Suma, Real]
    datos_barras = [vpp1_array', vpp2_array', vpp_teorico_array', vpp_real_array'];
    
    % Crear gráfico de barras agrupado
    b = bar(datos_barras, 'grouped');
    
    % Colores estéticos para cada barra
    b(1).FaceColor = [0.12 0.47 0.71]; % Azul (Electrodo 1)
    b(2).FaceColor = [1.00 0.50 0.05]; % Naranja (Electrodo 2)
    b(3).FaceColor = [0.55 0.55 0.55]; % Gris (Suma Teórica)
    b(4).FaceColor = [0.17 0.63 0.17]; % Verde (Medición Real)
    
    % Formato de ejes
    set(gca, 'XTickLabel', compose('Well %s', erase(string(nombres_validos), '.csv')), 'FontSize', 11);
    xlabel('Grid position', 'FontWeight', 'bold', 'FontSize', 12);
    ylabel('Peak-to-peak amplitude (mV)', 'FontWeight', 'bold', 'FontSize', 12);
    title('Exp 3: individual amplitudes and superposition in PBS', 'FontSize', 14);
    
    % Ampliar el eje Y para acomodar las etiquetas de error
    ylim([0, max([vpp_teorico_array, vpp_real_array]) * 1.15]);
    
   % Añadir la etiqueta del error justo entre la barra gris y la verde
    for k = 1:length(nombres_validos)
        % Altura máxima de la barra teórica y real para ese grupo
        altura_texto = max(datos_barras(k, 3), datos_barras(k, 4)) + 20;
        
        % Extraer la posición X exacta de la barra 3 (Gris) y la barra 4 (Verde)
        x_gris = b(3).XEndPoints(k);
        x_verde = b(4).XEndPoints(k);
        
        % Calcular el punto medio entre ambas
        x_centro = (x_gris + x_verde) / 2;
        
        % Crear y colocar el texto
        texto_error = sprintf('\\Delta = %.0f mV', error_array(k));
        text(x_centro, altura_texto, texto_error, 'HorizontalAlignment', 'center', ...
             'FontSize', 10, 'FontWeight', 'bold', 'Color', [0.85 0.32 0.1]);
    end
    
    % Leyenda y cuadrícula
    legend('Electrode 1 alone', 'Electrode 2 alone', 'Theoretical sum (E1 + E2)', 'Joint measurement (E1 + E2 on)', ...
           'Location', 'northoutside', 'Orientation', 'horizontal', 'FontSize', 10);
    grid on;
    set(gca, 'GridAlpha', 0.2);
else
    disp('No se encontraron datos válidos para graficar.');
end

disp('---------------------------------------------------------');
% Comparacion temporal adicional, sin alterar la fase de las capturas.
if ~isempty(ondas)
    figure('Name', 'Superposition: individual signals, sum and measurement', ...
        'Position', [80 60 1250 850], 'Color', 'w');
    panel = tiledlayout(numel(ondas), 1, 'TileSpacing', 'compact', 'Padding', 'compact');
    limite = 0;
    for k = 1:numel(ondas)
        o = ondas(k);
        limite = max(limite, max(abs([o.v1; o.v2; o.suma; o.real])));
    end
    limite = max(limite*1.08, eps);
    for k = 1:numel(ondas)
        o = ondas(k); ax = nexttile(panel);
        plot(ax, o.t*1000, 1000*o.v1, 'Color', [0.12 0.47 0.71], 'LineWidth', 1); hold(ax, 'on');
        plot(ax, o.t*1000, 1000*o.v2, 'Color', [1 0.50 0.05], 'LineWidth', 1);
        plot(ax, o.t*1000, 1000*o.suma, 'Color', [0.55 0.55 0.55], 'LineWidth', 1.4);
        plot(ax, o.t*1000, 1000*o.real, '--', 'Color', [0.17 0.63 0.17], 'LineWidth', 1.6);
        grid(ax, 'on'); ax.GridAlpha = 0.18;
        ylim(ax, 1000*[-limite limite]); xlim(ax, [o.t(1) o.t(end)]*1000);
        ylabel(ax, 'Voltage (mV)');
        title(ax, sprintf('Well %s | sum %.0f mVpp, measured %.0f mVpp (%.0f %% of the sum)', ...
            erase(o.nombre, '.csv'), o.vpp_suma, o.vpp_real, 100*o.vpp_real/o.vpp_suma));
        if k == 1
            lg = legend(ax, 'Electrode 1 alone', 'Electrode 2 alone', 'Sum of signals (E1 + E2)', ...
                'Joint measurement', 'Orientation', 'horizontal');
            lg.Layout.Tile = 'north';
        end
    end
    xlabel(panel, 'Oscilloscope time (ms)');
    title(panel, 'Exp 3: time-domain superposition by well');
    fprintf('Sin ajuste de fase: el error incluye posibles diferencias de disparo entre capturas.\n');
end

function vpp = VppRobusto(v)
% Amplitud pico a pico robusta, en las mismas unidades que v (aqui, V).
% Identico a ExtraerPicoAPico de Analisis_Placa.m salvo la conversion a mV.
    N = length(v);
    if N > 1000; v = v(floor(N*0.1):floor(N*0.9)); end
    v = smoothdata(v, 'movmean', max(5, floor(N/1000)));
    vpp = prctile(v, 99.9) - prctile(v, 0.1);
end

function o = PrepararOndas(data1, data2, data3, nombre)
% Ventana central de hasta 5 ms, tiempos originales y amplitudes en V.
% Interpolar a tiempos comunes no garantiza sincronizacion entre capturas.
o = []; datos = {data1, data2, data3};
for j = 1:3
    d = datos{j};
    d = d(all(isfinite(d(:,1:2)),2),1:2);
    [~, ids] = unique(d(:,1), 'sorted'); datos{j} = d(ids,:);
    if size(datos{j},1) < 2
        warning('Sin tiempos suficientes para %s.', nombre); return;
    end
end
inicio = max(cellfun(@(d) d(1,1), datos));
fin = min(cellfun(@(d) d(end,1), datos));
if fin <= inicio
    warning('Sin intervalo temporal comun para %s.', nombre); return;
end
centro = (inicio+fin)/2; semiventana = min(0.005, fin-inicio)/2;
d3 = datos{3}; sel = d3(:,1) >= centro-semiventana & d3(:,1) <= centro+semiventana;
t = d3(sel,1); real = d3(sel,2);
if numel(t) < 2, return; end
v1 = interp1(datos{1}(:,1), datos{1}(:,2), t, 'linear');
v2 = interp1(datos{2}(:,1), datos{2}(:,2), t, 'linear');
suma = v1+v2;
% Se comparan en pico a pico, que es la magnitud que usa toda la memoria.
vpp_suma = 1000 * VppRobusto(suma);
vpp_real = 1000 * VppRobusto(real);
ids = unique(round(linspace(1,numel(t),min(5000,numel(t)))));
o = struct('nombre', nombre, 't', t(ids), 'v1', v1(ids), 'v2', v2(ids), ...
    'suma', suma(ids), 'real', real(ids), 'vpp_suma', vpp_suma, 'vpp_real', vpp_real);
end
