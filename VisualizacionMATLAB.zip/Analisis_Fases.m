% TFM: EXPERIMENTO 4. Beamforming con cambios de fases (7 fases x 3 trials)
clear; clc; close all;
addpath(fileparts(mfilename('fullpath')));   % para GeometriaTapaNueva.m

% RUTAS A LOS EXPERIMENTOS Y ETIQUETAS
rutas_experimentos = {
    'C:\Users\julia\OneDrive\Escritorio\UPM\TFM\MATLAB\EXPERIMENTO4\1_trial', ...
    'C:\Users\julia\OneDrive\Escritorio\UPM\TFM\MATLAB\EXPERIMENTO4\2_trial', ...
    'C:\Users\julia\OneDrive\Escritorio\UPM\TFM\MATLAB\EXPERIMENTO4\3_trial'
};
nombres_experimentos = {'Exp 4, trial 1', 'Exp 4, trial 2', 'Exp 4, trial 3'};   % son los 3 trials del Exp 4

% Nombres de las subcarpetas TAL CUAL estan en disco (en mayusculas).
subcarpetas_fases = {'0', 'PI5', '2PI5', 'PI2', '3PI5', '4PI5', 'PI'};
nombres_fases     = {'0', 'pi5', '2pi5', 'pi2', '3pi5', '4pi5', 'pi'};
colores_fases     = lines(7);

voltaje_inyeccion = 600;   % mV PICO A PICO inyectados en los emisores
                           % (mismas unidades que las amplitudes medidas)

% Escala de color. [] = se calcula del dato y se aplica LA MISMA a las 7 fases
% al terminar cada experimento, que es lo que permite comparar unas fases con
% otras.
escala_colores_fija = [];

% CONFIGURACIÓN GEOMÉTRICA CALIBRADA
emisores = [7, 18];
masa     = 31;

% La geometría esta en GeometriaTapaNueva.m (una sola fuente para todos los scripts)
[coord_X, coord_Y, geo] = GeometriaTapaNueva();
radio_placa_petri = geo.radio_placa_petri;

puntos_posibles = setdiff(1:37, [emisores, masa]);

X_em1 = coord_X(emisores(1)); Y_em1 = coord_Y(emisores(1));
X_em2 = coord_X(emisores(2)); Y_em2 = coord_Y(emisores(2));
X_medio = (X_em1 + X_em2) / 2;
Y_medio = (Y_em1 + Y_em2) / 2;

% PROCESAMIENTO Y GRÁFICAS
ejes_decaimiento = gobjects(0);   % para igualar el eje Y de los 3 trials al final
v_max_global     = 0;

for exp_idx = 1:length(rutas_experimentos)
    ruta_exp_base = rutas_experimentos{exp_idx};
    nombre_exp = nombres_experimentos{exp_idx};

    fprintf('\nProcesando: %s...\n', nombre_exp);

    fig_decaimiento = figure('Name', sprintf('Amplitude versus distance - %s', nombre_exp), 'Position', [50, 50, 850, 500]);
    hold on; grid on;

    fig_heatmap = figure('Name', sprintf('Phase heatmaps - %s', nombre_exp), 'Position', [180, 150, 1400, 750]);
    panel_heat  = tiledlayout(fig_heatmap, 2, 4, 'TileSpacing', 'compact', 'Padding', 'compact');

    % Variables para asegurar que tenemos datos
    dist_unicas = [];
    hubo_datos_experimento = false;
    ejes_fase = gobjects(0);   % ejes de los mapas, para igualarles la escala
    v_min_exp = inf; v_max_exp = -inf;

    for fase_idx = 1:length(subcarpetas_fases)
        ruta_actual = fullfile(ruta_exp_base, subcarpetas_fases{fase_idx});
        nombre_fase = nombres_fases{fase_idx};
        color_actual = colores_fases(fase_idx, :);

        archivo_cache = fullfile(ruta_actual, 'datos_procesados_2E_v11.mat');

        % Comprobamos si la ruta de la fase existe realmente
        if ~isfolder(ruta_actual)
            fprintf('  -> [AVISO] No se encuentra la carpeta: %s\n', ruta_actual);
            continue;
        end

        if isfile(archivo_cache)
            load(archivo_cache, 'amplitudes_mV', 'distancias_radiales_reales', 'X_medidos', 'Y_medidos');
        else
            amplitudes_mV = []; distancias_radiales_reales = [];
            X_medidos = []; Y_medidos = [];

            for p = 1:length(puntos_posibles)
                id_pocillo = puntos_posibles(p);
                filepath = fullfile(ruta_actual, sprintf('%d.csv', id_pocillo));

                if isfile(filepath)
                    X_act = coord_X(id_pocillo); Y_act = coord_Y(id_pocillo);
                    dist_real = sqrt((X_act - X_medio)^2 + (Y_act - Y_medio)^2);

                    data = readmatrix(filepath);
                    if size(data, 2) >= 2; v = data(:, 2); else; v = data(:, 1); end
                    v = v(~isnan(v));

                    N = length(v);
                    if N > 1000; v_limp = v(floor(N*0.1):floor(N*0.9)); else; v_limp = v; end
                    v_suaves = smoothdata(v_limp, 'movmean', max(5, floor(N/1000)));
                    v_max = prctile(v_suaves, 99.9); v_min = prctile(v_suaves, 0.1);
                    val_mV = v_max - v_min; if val_mV < 10; val_mV = val_mV * 1000; end

                    amplitudes_mV(end+1) = val_mV;
                    distancias_radiales_reales(end+1) = round(dist_real, 1);
                    X_medidos(end+1) = X_act; Y_medidos(end+1) = Y_act;
                end
            end
            if ~isempty(amplitudes_mV)
                save(archivo_cache, 'amplitudes_mV', 'distancias_radiales_reales', 'X_medidos', 'Y_medidos');
            end
        end

        if isempty(amplitudes_mV)
            fprintf('  -> [AVISO] No hay datos CSV válidos en: %s\n', subcarpetas_fases{fase_idx});
            continue;
        end

        hubo_datos_experimento = true;

        % Extraer dist_unicas
        dist_unicas = unique(distancias_radiales_reales);
        ampl_medias = zeros(1, length(dist_unicas));
        for k = 1:length(dist_unicas)
            ampl_medias(k) = mean(amplitudes_mV(distancias_radiales_reales == dist_unicas(k)));
        end

        figure(fig_decaimiento);
        plot(dist_unicas, ampl_medias, '-o', 'LineWidth', 2, 'MarkerSize', 6, ...
            'MarkerFaceColor', color_actual, 'Color', color_actual, 'DisplayName', sprintf('Phase %s', nombre_fase));

        v_min_exp = min(v_min_exp, min(amplitudes_mV));
        v_max_exp = max(v_max_exp, max(amplitudes_mV));
        v_max_global = max(v_max_global, max(amplitudes_mV));

        % --- MAPA INTERPOLADO (solo con lo medido) -------------------------
        ax = nexttile(panel_heat, fase_idx);
        ejes_fase(end+1) = ax;  
        DibujarMapaPlaca(X_medidos, Y_medidos, amplitudes_mV, struct( ...
            'radio_placa',   radio_placa_petri, ...
            'emisores_XY',   [X_em1 X_em2; Y_em1 Y_em2], ...
            'masa_XY',       [coord_X(masa); coord_Y(masa)], ...
            'escala',        escala_colores_fija, ...
            'resolucion',    200, ...
            'colorbar',      false, ...
            'ejes',          ax, ...
            'titulo',        sprintf('Phase: %s', nombre_fase)));
        xlabel(ax, ''); ylabel(ax, '');
    end % Fin bucle de fases

    % --- MISMA ESCALA DE COLOR EN LAS 7 FASES ----------------------------
    if isempty(escala_colores_fija)
        escala_exp = [v_min_exp, v_max_exp];
    else
        escala_exp = escala_colores_fija;
    end
    if isfinite(escala_exp(1)) && escala_exp(2) > escala_exp(1)
        for a = ejes_fase
            clim(a, escala_exp);
        end
        fprintf('  Escala de color comun a las 7 fases: %.0f a %.0f mV\n', ...
                escala_exp(1), escala_exp(2));
    end

    % Solo cerramos y etiquetamos las figuras si hubo datos
    if hubo_datos_experimento && ~isempty(dist_unicas)
        figure(fig_decaimiento);
        % entre 32.5 y 38 mm hay 5 distancias distintas y sus etiquetas se montaban unas sobre otras.
        xticks('auto'); xtickangle(0);
        xlabel('Distance to the midpoint between electrodes (mm)', 'FontWeight', 'bold');
        ylabel('Measured peak-to-peak amplitude (mV)', 'FontWeight', 'bold');
        title(sprintf('Amplitude versus distance by phase: %s', nombre_exp), 'FontSize', 14);
        lgd = legend('Location', 'best'); title(lgd, 'Applied phases');
        ejes_decaimiento(end+1) = gca;

        title(panel_heat, sprintf('Peak-to-peak amplitude by phase (spatially interpolated) - %s', nombre_exp), ...
              'FontSize', 15, 'FontWeight', 'bold');
        % La barra se cuelga del primer mapa; todos tienen el mismo clim.
        c = colorbar(ejes_fase(1)); c.Layout.Tile = 'east';
        c.Label.String = 'Peak-to-peak amplitude (mV)';

    else
        fprintf('  -> NO se generaron gráficas para el %s por falta de datos.\n', nombre_exp);
        close(fig_decaimiento); close(fig_heatmap);
    end

end

% Eje Y comun a las figuras de decaimiento de los tres trials, desde 0
for a = ejes_decaimiento
    ylim(a, [0, 1.08 * v_max_global]);
end

