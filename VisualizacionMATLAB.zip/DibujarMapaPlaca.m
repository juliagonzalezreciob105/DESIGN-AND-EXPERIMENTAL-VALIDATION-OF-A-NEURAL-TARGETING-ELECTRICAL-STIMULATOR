function [Xq, Yq, Vq] = DibujarMapaPlaca(X_med, Y_med, V_med, opt)
% =========================================================================
% MAPA INTERPOLADO DEL POTENCIAL MEDIDO SOBRE LA PLACA
%
% El mapa se construye SOLO a partir de los pocillos medidos:
% - Los emisores NO se introducen como medidas.
% - La pared NO recibe valores artificiales.
% - Entre pocillos se interpola por vecino natural, que nunca se sale del
%   rango de los datos.
% - Hasta la pared se completa reflejando los puntos medidos respecto a la
%   pared (pared aislante: la derivada radial se anula). Es una extension
%   geometrica aproximada; fuera de la envolvente de las medidas el mapa es
%   una estimacion de borde, no una medida.
%
% opt (todos opcionales):
%   radio_placa   mm (45)
%   emisores_XY   [x; y] de los emisores (se dibujan en rojo)
%   masa_XY       [x; y] de la masa (cuadrado negro)
%   escala        [min max] de la barra de color; [] = rango del mapa
%   resolucion    puntos por eje de la malla (300)
%   titulo, etiqueta (texto de la barra), ejes (axes donde dibujar), colorbar
% =========================================================================

if nargin < 4; opt = struct(); end
def = struct('radio_placa', 45, 'emisores_XY', [], 'masa_XY', [], 'escala', [], ...
             'resolucion', 300, 'titulo', '', 'etiqueta', 'Peak-to-peak amplitude (mV)', ...
             'ejes', [], 'colorbar', true);
nombres = fieldnames(def);
for i = 1:numel(nombres)
    if ~isfield(opt, nombres{i}) || isempty(opt.(nombres{i})); opt.(nombres{i}) = def.(nombres{i}); end
end

% =========================================================================
% PREPARAR DATOS
% =========================================================================
X_med = X_med(:)'; Y_med = Y_med(:)'; V_med = V_med(:)';
if numel(X_med) ~= numel(Y_med) || numel(X_med) ~= numel(V_med)
    error('DibujarMapaPlaca:Dimensiones', 'X, Y y V deben tener igual longitud.');
end
validos = isfinite(X_med) & isfinite(Y_med) & isfinite(V_med);
X_med = X_med(validos); Y_med = Y_med(validos); V_med = V_med(validos);
if isempty(X_med)
    warning('No hay datos validos para construir el mapa.');
    Xq = []; Yq = []; Vq = []; return;
end

% Promediar medidas repetidas en la misma posicion
[xy, ~, grupo] = unique([X_med(:), Y_med(:)], 'rows');
V_med = accumarray(grupo, V_med(:), [], @mean)';
X_med = xy(:,1)'; Y_med = xy(:,2)';
if size(xy,1) < 3 || rank(xy - mean(xy,1)) < 2
    error('DibujarMapaPlaca:Geometria', 'Se necesitan tres posiciones no colineales.');
end
R = opt.radio_placa;
if any(hypot(X_med, Y_med) > R + 1e-6)
    error('DibujarMapaPlaca:FueraPlaca', 'Hay medidas fuera del radio de la placa.');
end

% =========================================================================
% MALLA, REFLEXION EN LA PARED E INTERPOLACION
% =========================================================================
xv = linspace(-R, R, opt.resolucion);
[Xq, Yq] = meshgrid(xv, xv);

% Reflexion de cada punto medido respecto a la pared circular (mismo valor
% de tension): da informacion al interpolador cerca del borde sin inventar
% ningun nivel de potencial nuevo.
r_med = hypot(X_med, Y_med);
sel   = r_med > 1e-6;
fac   = (2*R - r_med(sel)) ./ r_med(sel);
X_int = [X_med, X_med(sel) .* fac];
Y_int = [Y_med, Y_med(sel) .* fac];
V_int = [V_med, V_med(sel)];

F  = scatteredInterpolant(X_int', Y_int', V_int', 'natural', 'none');
Vq = F(Xq, Yq);
Vq(hypot(Xq, Yq) > R) = NaN;

% =========================================================================
% DIBUJO
% =========================================================================
if isempty(opt.ejes); ax = gca; else; ax = opt.ejes; end
axes(ax); cla(ax); hold(ax, 'on');

im = imagesc(ax, xv, xv, Vq);
set(im, 'AlphaData', ~isnan(Vq));
set(ax, 'YDir', 'normal', 'Color', 'w');
colormap(ax, parula(256));

if isempty(opt.escala)
    vals = Vq(~isnan(Vq));
    if isempty(vals); escala = [0 1]; else; escala = [min(vals), max(vals)]; end
    if escala(1) == escala(2); escala = escala + [-1 1]; end
else
    escala = opt.escala;
end
clim(ax, escala);

rectangle(ax, 'Position', [-R, -R, 2*R, 2*R], 'Curvature', [1 1], 'LineWidth', 2.5, 'EdgeColor', 'k');
plot(ax, X_med, Y_med, 'ko', 'MarkerSize', 4, 'MarkerFaceColor', 'w');
if ~isempty(opt.emisores_XY)
    plot(ax, opt.emisores_XY(1,:), opt.emisores_XY(2,:), 'r+', 'MarkerSize', 10, 'LineWidth', 2);
end
if ~isempty(opt.masa_XY)
    plot(ax, opt.masa_XY(1), opt.masa_XY(2), 'ks', 'MarkerSize', 10, 'LineWidth', 2, 'MarkerFaceColor', 'k');
end

axis(ax, 'equal');
xlim(ax, 1.11*[-R R]); ylim(ax, 1.11*[-R R]);
grid(ax, 'on');
set(ax, 'Layer', 'top', 'FontSize', 11);
if opt.colorbar
    c = colorbar(ax); c.Label.String = opt.etiqueta;
end
if ~isempty(opt.titulo); title(ax, opt.titulo, 'FontSize', 13); end
xlabel(ax, 'X position (mm)', 'FontWeight', 'bold');
ylabel(ax, 'Y position (mm)', 'FontWeight', 'bold');
end
