% =========================================================================
% TFM: EXPERIMENTO 1. TAPA ANTIGUA + ELECTRODOS DE TUNGSTENO (13 electrodos)
% Lectura de los .mat + Comparativa por electrodo + Decaimiento + Heatmap
% =========================================================================
clear; clc; close all;
addpath(fileparts(mfilename('fullpath')));

% =========================================================================
% 1. CONFIGURACION
% =========================================================================
ruta_base = 'C:\Users\julia\OneDrive\Escritorio\UPM\TFM\MATLAB\EXPERIMENTO1';

experimentos = {'beamforming1', 'beamforming2', 'beamforming3'};   % subcarpetas del Exp 1
prefijo      = 'Exp 1';
trials       = {'TRIAL1', 'TRIAL2', 'TRIAL3'};
n_electrodos = 13;

colores_experimentos = {'#2ca02c', '#7f7f7f', '#98df8a'};

% Electrodos de TENSION de cada experimento
% El resto se tratan como electrodos de medida. 
emisores_por_experimento = { ...
    [12,  2], ...   % beamforming1
    [12,  7], ...   % beamforming2
    [12,  7] };     % beamforming3

paso_diezmado = 20;        % 1 de cada N muestras (20e6 -> 1e6). Sube si va lento.
archivo_cache = fullfile(ruta_base, 'cache_TapaAntigua_v1.mat');

% Mapas interpolados sobre la geometria aproximada de la tapa antigua. Con
% solo 13 electrodos la periferia tiene poco soporte experimental.
%
% ESCALA DE COLOR DE LOS MAPAS: [min max] en mV, comun a los tres trials de
% cada ensayo.
escala_colores_fija = [0 NaN];    % mV

% Los limites del eje Y de las curvas siguen siendo por trial
% =========================================================================
% 2. GEOMETRIA DE LA TAPA ANTIGUA

radio_placa = 45;    % mm
a_paso      = 25;    % mm, paso horizontal de las filas anchas (2,5 cm)
b_paso      = 13;    % mm, paso vertical entre filas (1,3 cm)

%                             X(mm)          Y(mm)          % fila
coord_ANTIGUA = [  ...
    -a_paso    , -2*b_paso ;  ...  % e1   abajo,  izquierda
     a_paso    , -2*b_paso ;  ...  % e2   abajo,  derecha
     a_paso    ,  2*b_paso ;  ...  % e3   arriba, derecha
    -a_paso    ,  2*b_paso ;  ...  % e4   arriba, izquierda
     0         ,  2*b_paso ;  ...  % e5   arriba, centro
     a_paso/2  ,   -b_paso ;  ...  % e6   intercalada inferior, derecha
     a_paso/2  ,    b_paso ;  ...  % e7   intercalada superior, derecha
     0         , -2*b_paso ;  ...  % e8   abajo,  centro
     0         ,  0        ;  ...  % e9   CENTRO de la placa
     a_paso    ,  0        ;  ...  % e10  eje horizontal, derecha
    -a_paso/2  ,   -b_paso ;  ...  % e11  intercalada inferior, izquierda
    -a_paso/2  ,    b_paso ;  ...  % e12  intercalada superior, izquierda
    -a_paso    ,  0        ];      % e13  eje horizontal, izquierda

coord_X = coord_ANTIGUA(:, 1)';
coord_Y = coord_ANTIGUA(:, 2)';

% --- Mapa de la tapa antigua (para comparar de un vistazo con la foto) ---
figure('Name', 'Old lid geometry (13 tungsten electrodes)', ...
       'Position', [150, 90, 700, 690], 'Color', 'w');
hold on; axis equal; grid on;
rectangle('Position', [-radio_placa, -radio_placa, radio_placa*2, radio_placa*2], ...
          'Curvature', [1, 1], 'LineWidth', 2.5, 'EdgeColor', 'k');
plot([-radio_placa radio_placa], [0 0], 'k:', 'Color', [0.75 0.75 0.75]);
plot([0 0], [-radio_placa radio_placa], 'k:', 'Color', [0.75 0.75 0.75]);
plot(coord_X, coord_Y, 'o', 'MarkerSize', 11, 'MarkerFaceColor', '#2ca02c', 'MarkerEdgeColor', 'k');
for k = 1:n_electrodos
    text(coord_X(k), coord_Y(k) + 3.5, sprintf('%d', k), 'HorizontalAlignment', 'center', ...
         'FontSize', 11, 'FontWeight', 'bold', 'Color', [0.75 0 0]);
end
xlim([-50 50]); ylim([-50 50]);
xlabel('X position (mm)', 'FontSize', 12, 'FontWeight', 'bold');
ylabel('Y position (mm)', 'FontSize', 12, 'FontWeight', 'bold');
title(sprintf('Exp 1, old lid: 13 electrodes (spacing %g / %g mm, 9 = centre)', a_paso, b_paso), ...
      'FontSize', 13);
set(gca, 'FontSize', 11);

% =========================================================================
% 3. LECTURA DE LOS .MAT (con cache)
% =========================================================================
if isfile(archivo_cache)
    fprintf('Cargando amplitudes desde cache...\n');
    load(archivo_cache, 'amplitudes');
else
    fprintf('Procesando los .mat por primera vez (tarda un rato)...\n');
    amplitudes = nan(numel(experimentos), numel(trials), n_electrodos);

    for e = 1:numel(experimentos)
        for t = 1:numel(trials)
            carpeta = fullfile(ruta_base, sprintf('%s_%s', experimentos{e}, trials{t}));
            if ~isfolder(carpeta); continue; end
            for k = 1:n_electrodos
                f = fullfile(carpeta, sprintf('e%d.mat', k));
                if ~isfile(f); continue; end
                
                S = load(f, 'C1_data');
                v = double(S.C1_data(1:paso_diezmado:end));
                clear S;
                v = v(:);
                v = v(~isnan(v));
                if isempty(v); continue; end

                N = numel(v);
                if N > 1000; v = v(floor(N*0.1):floor(N*0.9)); end
                v = smoothdata(v, 'movmean', max(5, floor(numel(v)/1000)));

                pkpk = prctile(v, 99.9) - prctile(v, 0.1);
                if pkpk < 10; pkpk = pkpk * 1000; end     % V -> mV
                amplitudes(e, t, k) = pkpk;

                fprintf('  %s_%s  e%-2d -> %8.2f mV\n', experimentos{e}, trials{t}, k, pkpk);
            end
        end
    end
    save(archivo_cache, 'amplitudes');
    fprintf('Cache guardada en %s\n', archivo_cache);
end

% =========================================================================
% 4. TRIALS SEPARADOS: una figura por experimento y tipo de grafica
% =========================================================================
txt_amp = 'Peak-to-peak amplitude (mV)';

for e = 1:numel(experimentos)
    valores_exp = reshape(amplitudes(e,:,:), numel(trials), n_electrodos);
    finitos = valores_exp(isfinite(valores_exp));
    if isempty(finitos)
        warning('Sin datos para %s.', experimentos{e});
        continue;
    end
    emisores = emisores_por_experimento{e};
    X_ref = mean(coord_X(emisores));
    Y_ref = mean(coord_Y(emisores));

    escala_mapa = RangoSeguro(finitos);                 % rango medido del ensayo (3 trials)
    fijo = ~isnan(escala_colores_fija);
    escala_mapa(fijo) = escala_colores_fija(fijo);
    txt_escala = sprintf('colour scale %.0f-%.0f mV, common to the three trials; y-limits per trial', ...
                         escala_mapa(1), escala_mapa(2));
    if max(finitos) > escala_mapa(2) || min(finitos) < escala_mapa(1)
        fprintf('[AVISO] %s: medido %.0f-%.0f mV, fuera de la escala de color [%.0f %.0f]; se pinta saturado.\n', ...
                experimentos{e}, min(finitos), max(finitos), escala_mapa(1), escala_mapa(2));
    end

    figure('Name', sprintf('Amplitude by electrode - %s', experimentos{e}), ...
        'Position', [60 100 1450 470], 'Color', 'w');
    panel_amp = tiledlayout(1, numel(trials), 'TileSpacing', 'compact', 'Padding', 'compact');
    title(panel_amp, {sprintf('%s, %s: amplitude by electrode', prefijo, experimentos{e}), txt_escala});

    figure('Name', sprintf('Amplitude versus distance - %s', experimentos{e}), ...
        'Position', [80 120 1450 470], 'Color', 'w');
    panel_dist = tiledlayout(1, numel(trials), 'TileSpacing', 'compact', 'Padding', 'compact');
    title(panel_dist, {sprintf('%s, %s: amplitude versus distance (stimulating electrodes excluded)', ...
                               prefijo, experimentos{e}), txt_escala});

    figure('Name', sprintf('Heatmap - %s', experimentos{e}), ...
        'Position', [100 140 1550 510], 'Color', 'w');
    panel_mapa = tiledlayout(1, numel(trials), 'TileSpacing', 'compact', 'Padding', 'compact');
    title(panel_mapa, {sprintf('%s, %s: peak-to-peak amplitude', prefijo, experimentos{e}), txt_escala});
    ejes_mapa = gobjects(0);

    for t = 1:numel(trials)
        v_trial = valores_exp(t,:);
        validos = isfinite(v_trial);
        medidos = setdiff(find(validos), emisores);   % de medida, sin emisores

        % --- limites de Y de ESTE trial ----------------------------------
        if any(validos)
            r_trial = RangoSeguro(v_trial(validos));
        else
            r_trial = RangoSeguro(finitos);
        end
        limites_amp = r_trial + [-1 1]*0.05*diff(r_trial);
        if ~isempty(medidos)
            r_med = RangoSeguro(v_trial(medidos));
            limites_dist = r_med + [-1 1]*0.05*diff(r_med);
        else
            limites_dist = limites_amp;
        end

        % --- A) amplitud por electrodo -----------------------------------
        ax = nexttile(panel_amp, t);
        plot(ax, 1:n_electrodos, v_trial, '-o', 'Color', colores_experimentos{e}, ...
            'LineWidth', 1.5, 'MarkerSize', 5, 'MarkerFaceColor', colores_experimentos{e}, ...
            'DisplayName', 'Measured amplitude');
        hold(ax, 'on');
        plot(ax, emisores, v_trial(emisores), 'r+', 'MarkerSize', 11, 'LineWidth', 2, ...
            'DisplayName', 'Stimulating electrodes');
        xticks(ax, 1:n_electrodos); xticklabels(ax, compose('e%d', 1:n_electrodos));
        xlim(ax, [0.5 n_electrodos+0.5]); ylim(ax, limites_amp); grid(ax, 'on');
        xlabel(ax, 'Electrode'); ylabel(ax, txt_amp); title(ax, trials{t});
        if t == 1, legend(ax, 'Location', 'best'); end
        if ~any(validos), title(ax, [trials{t} ' - No data']); end

        % --- B) amplitud frente a distancia (sin emisores) ----------------
        ax = nexttile(panel_dist, t);
        distancia = hypot(coord_X(medidos)-X_ref, coord_Y(medidos)-Y_ref);
        [distancia, orden] = sort(distancia);
        ids = medidos(orden);
        plot(ax, distancia, v_trial(ids), '-o', 'Color', colores_experimentos{e}, ...
            'LineWidth', 1.5, 'MarkerSize', 5, 'MarkerFaceColor', colores_experimentos{e});
        for k = 1:numel(ids)
            text(ax, distancia(k), v_trial(ids(k)), sprintf(' e%d', ids(k)), 'FontSize', 8);
        end
        todos_medidos = setdiff(1:n_electrodos, emisores);
        max_dist = max(hypot(coord_X(todos_medidos)-X_ref, coord_Y(todos_medidos)-Y_ref));
        xlim(ax, [0 max(1, max_dist*1.05)]); ylim(ax, limites_dist); grid(ax, 'on');
        xlabel(ax, 'Distance to the emission centre (mm)');
        ylabel(ax, txt_amp); title(ax, trials{t});
        if isempty(ids), title(ax, [trials{t} ' - No data']); end

        % --- C) mapa interpolado -----------------------------------------
        ax = nexttile(panel_mapa, t);
        xy = [coord_X(validos); coord_Y(validos)]';
        if size(xy,1) < 3 || rank(xy-mean(xy,1)) < 2
            axis(ax, 'off'); title(ax, [trials{t} ' - Insufficient data']);
            continue;
        end
        % Se incluyen las tensiones medidas en los emisores de ESTE trial.
        DibujarMapaPlaca(coord_X(validos), coord_Y(validos), v_trial(validos), struct( ...
            'ejes', ax, 'radio_placa', radio_placa, ...
            'escala', escala_mapa, 'colorbar', false, 'titulo', trials{t}, ...
            'emisores_XY', [coord_X(emisores); coord_Y(emisores)]));
        ejes_mapa(end+1) = ax; %#ok<SAGROW>
        for k = 1:n_electrodos
            text(ax, coord_X(k), coord_Y(k)+3, sprintf('e%d', k), ...
                'HorizontalAlignment', 'center', 'FontSize', 8, 'Color', [0.2 0.2 0.2]);
        end
    end
    % Una sola barra de color por figura (todos los mapas comparten escala)
    if ~isempty(ejes_mapa)
        cb = colorbar(ejes_mapa(1)); cb.Layout.Tile = 'east'; cb.Label.String = txt_amp;
    end
end

% =========================================================================
% FUNCIONES AUXILIARES
% =========================================================================
function r = RangoSeguro(v)
% [min max] de v, abierto un poco si todos los valores son iguales para que
    r = [min(v), max(v)];
    if r(1) == r(2)
        r = r + [-1 1]*max(1, abs(r(1))*0.01);
    end
end
