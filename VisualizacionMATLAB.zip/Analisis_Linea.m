% TFM: EXPERIMENTO 2  - Caida de tension a lo largo de la linea vertical
% una figura por experimento con las 4 condiciones (1 kHz / 28 Hz, con y sin masa).
% Medidas en linea con el electrodo de tension en el POCILLO 23 (0, -10)
% =========================================================================
clear; clc; close all;
% =========================================================================
% 1. CONFIGURACION
% =========================================================================
ruta_principal = 'C:\Users\julia\OneDrive\Escritorio\UPM\TFM\MATLAB\EXPERIMENTO2';

% Experimentos 01 y 02 solo tienen 7 puntos; del 03 en adelante hay 8.
carpetas_exp = {'beamforming_01', 'beamforming_02', 'beamforming_03', ...
                'beamforming_04', 'beamforming_05'};

carpeta_1kHz_masa = '1kHz-masa';
carpeta_28Hz_masa = '28Hz-masa';
carpeta_1kHz_sin  = '1kHz-sinMasa';
carpeta_28Hz_sin  = '28Hz-sinMasa';

% Amplitud pico a pico: percentiles 0.1 / 99.9 sobre la senal suavizada, el
% mismo metodo que todos los demas scripts. 
% Puntos de la linea y su distancia al emisor (pocillo 23)
puntos         = [32,     3,  8,  13, 18,  26,    27,  33];
distancias_abs = [34.75, 20, 15,  10,  5, 14.75,  25,  45];

archivo_cache = fullfile(ruta_principal, 'cache_Linea_pkpk.mat');

color_1kHz     = '#008000';   % verde oscuro (con masa)
color_28Hz     = '#000000';   % negro        (con masa)
color_1kHz_sin = '#32CD32';   % verde claro  (sin masa)
color_28Hz_sin = '#808080';   % gris         (sin masa)

num_puntos = numel(puntos);
num_exps   = numel(carpetas_exp);

% =========================================================================
% 2. LECTURA Y PROCESAMIENTO (CON CACHE)
% =========================================================================
if isfile(archivo_cache)
    fprintf('Cargando datos desde %s...\n', archivo_cache);
    load(archivo_cache, 'val_1kHz_masa', 'val_28Hz_masa', 'val_1kHz_sin', 'val_28Hz_sin');
else
    fprintf('Procesando los .csv por primera vez (tarda un rato)...\n');
    val_1kHz_masa = nan(num_exps, num_puntos);
    val_28Hz_masa = nan(num_exps, num_puntos);
    val_1kHz_sin  = nan(num_exps, num_puntos);
    val_28Hz_sin  = nan(num_exps, num_puntos);

    for e = 1:num_exps
        ruta_exp = fullfile(ruta_principal, carpetas_exp{e});
        fprintf('-> %s\n', carpetas_exp{e});
        for p = 1:num_puntos
            nombre_archivo = sprintf('%d.csv', puntos(p));
            val_1kHz_masa(e, p) = ExtraerAmplitud(fullfile(ruta_exp, carpeta_1kHz_masa, nombre_archivo));
            val_28Hz_masa(e, p) = ExtraerAmplitud(fullfile(ruta_exp, carpeta_28Hz_masa, nombre_archivo));
            val_1kHz_sin(e, p)  = ExtraerAmplitud(fullfile(ruta_exp, carpeta_1kHz_sin,  nombre_archivo));
            val_28Hz_sin(e, p)  = ExtraerAmplitud(fullfile(ruta_exp, carpeta_28Hz_sin,  nombre_archivo));
        end
    end
    save(archivo_cache, 'val_1kHz_masa', 'val_28Hz_masa', 'val_1kHz_sin', 'val_28Hz_sin');
    fprintf('Cache guardada.\n\n');
end

% =========================================================================
% 3. GRAFICAS: una por experimento, con las 4 condiciones
% =========================================================================
[dist_ordenadas, indices] = sort(distancias_abs);

% Las 4 condiciones, en el orden de la leyenda
series = { val_1kHz_masa, '-o',  color_1kHz,     '1 kHz (grounded)';
           val_28Hz_masa, '-s',  color_28Hz,     '28 Hz (grounded)';
           val_1kHz_sin,  '--^', color_1kHz_sin, '1 kHz (no ground)';
           val_28Hz_sin,  '--v', color_28Hz_sin, '28 Hz (no ground)' };

for e = 1:num_exps
    figure('Name', sprintf('%s - Amplitude versus distance', carpetas_exp{e}), ...
           'Position', [100 + e*40, 200 - e*15, 750, 500]);
    hold on; grid on;

    for s = 1:size(series, 1)
        y = series{s, 1}(e, indices);
        % Solo los puntos con dato: si falta un .csv en medio de la linea
        % (beamforming_05, 28 Hz sin masa, 10 mm) la linea une los vecinos en vez de cortarse
        ok = isfinite(y);
        if ~any(ok); continue; end
        plot(dist_ordenadas(ok), y(ok), series{s, 2}, 'LineWidth', 2.2, 'MarkerSize', 8, ...
            'MarkerFaceColor', series{s, 3}, 'Color', series{s, 3}, ...
            'DisplayName', series{s, 4});
    end

    % Ticks redondeados: 14.75 y 15 son puntos distintos pero sus
    % etiquetas se solapan si se ponen las dos. 
    xticks(unique(round(dist_ordenadas))); xtickangle(45);
    xlabel('Absolute distance to the stimulating electrode (mm)', 'FontSize', 12, 'FontWeight', 'bold');
    ylabel('Measured peak-to-peak amplitude (mV)', 'FontSize', 12, 'FontWeight', 'bold');
    title(sprintf('Exp 2, %s: Amplitude versus distance in PBS', strrep(carpetas_exp{e}, '_', ' ')), 'FontSize', 14);
    lgd = legend('Location', 'best'); title(lgd, 'Conditions');
    set(gca, 'FontSize', 11);
    xlim([0, 50]);
    % Eje Y comun a los cinco experimentos (y desde 0), para que sean comparables
    ylim([0, 1.08 * max([val_1kHz_masa(:); val_28Hz_masa(:); val_1kHz_sin(:); val_28Hz_sin(:)], [], 'omitnan')]);
end

% =========================================================================
% 4. VERIFICACION VISUAL DE LA EXTRACCION
%    Dibuja la senal cruda, la suavizada y los limites de los percentiles.
% =========================================================================
archivo_verificacion = fullfile(ruta_principal, 'beamforming_03', carpeta_1kHz_masa, '18.csv');

if ~isempty(archivo_verificacion) && isfile(archivo_verificacion)
    fprintf('\nComprobacion de senal sobre: %s\n', archivo_verificacion);
    ComprobarSenal(archivo_verificacion);
elseif ~isempty(archivo_verificacion)
    fprintf('\n[!] No se encontro el archivo de verificacion: %s\n', archivo_verificacion);
end

% =========================================================================
% FUNCIONES AUXILIARES
% =========================================================================
function val = ExtraerAmplitud(filepath)
    if ~isfile(filepath)
        fprintf('  [!] No se encontro: %s\n', filepath);
        val = NaN; return;
    end
    data = readmatrix(filepath);
    if size(data, 2) >= 2; v = data(:, 2); else; v = data(:, 1); end
    v = v(~isnan(v));
    if isempty(v); val = NaN; return; end

    N = length(v);
    if N > 1000; v = v(floor(N*0.10):floor(N*0.90)); end
    v = smoothdata(v, 'movmean', max(5, floor(length(v)/1000)));
    val = prctile(v, 99.9) - prctile(v, 0.1);

    if val < 10; val = val * 1000; end             % V -> mV
end

function ComprobarSenal(filepath)
% Comprueba a ojo que la deteccion de pico a pico esta cogiendo bien la senal:
% pinta la senal cruda, la suavizada y las dos lineas de los percentiles.
    data = readmatrix(filepath);
    if size(data, 2) >= 2; v = data(:, 2); else; v = data(:, 1); end
    v = v(~isnan(v));

    N = length(v);
    if N > 1000; v_limp = v(floor(N*0.10):floor(N*0.90)); else; v_limp = v; end
    v_suaves = smoothdata(v_limp, 'movmean', max(5, floor(length(v_limp)/1000)));

    v_max = prctile(v_suaves, 99.9);
    v_min = prctile(v_suaves, 0.1);
    pkpk  = v_max - v_min;
    if pkpk < 10; pkpk_mostrar = pkpk * 1000; else; pkpk_mostrar = pkpk; end

    salto  = max(1, floor(length(v_limp) / 5000));
    x_plot = 1:salto:length(v_limp);

    figure('Name', 'Amplitude extraction check - recorded signal', 'Position', [350, 100, 800, 450]);
    plot(x_plot, v_limp(1:salto:end),   'Color', '#32CD32', 'DisplayName', 'Raw signal'); hold on;
    plot(x_plot, v_suaves(1:salto:end), 'Color', '#000000', 'LineWidth', 1.5, 'DisplayName', 'Smoothed signal');
    yline(v_max, '--r', 'LineWidth', 2, 'DisplayName', sprintf('Upper limit, 99.9th percentile (%.4f V)', v_max));
    yline(v_min, '--b', 'LineWidth', 2, 'DisplayName', sprintf('Lower limit, 0.1st percentile (%.4f V)', v_min));

    title(sprintf('Exp 2, amplitude extraction check: %.1f mV peak-to-peak', pkpk_mostrar));
    xlabel('Samples analysed (10% to 90% of the record)'); ylabel('Voltage (V)');
    legend('Location', 'best'); grid on;

    margen = pkpk * 0.1;
    ylim([v_min - margen, v_max + margen]);
end
